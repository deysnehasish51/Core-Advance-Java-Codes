//Cricketer.java
package com.nt.sbeans;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

@Component("cktr")
public final class Cricketer {
	@Autowired
	@Qualifier("mrf")
	private  ICricketBat  bat;
	
	private Cricketer() {
		System.out.println("Cricketer:: 0-param constructor");
	}
	
	// b.method
	public  String   batting() {
		System.out.println("Cricketer.batting()");
		//use  the dependent object
		int runs=bat.scoreRuns();
		return "Cricketer has scored "+runs +" in batting";
	}

}
