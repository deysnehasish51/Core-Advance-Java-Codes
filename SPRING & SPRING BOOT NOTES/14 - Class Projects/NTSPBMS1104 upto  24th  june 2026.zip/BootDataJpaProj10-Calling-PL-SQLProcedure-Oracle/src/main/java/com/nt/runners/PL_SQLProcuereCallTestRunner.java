package com.nt.runners;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import com.nt.entity.Customer;
import com.nt.service.ICustomerMgmtService;

@Component
public class PL_SQLProcuereCallTestRunner implements CommandLineRunner {
	@Autowired
	private  ICustomerMgmtService  custService;

	@Override
	public void run(String... args) throws Exception {
		try {
			List<Customer>  list=custService.showCustomerDetailsByBillAmtRange(1000.0, 4000.0);
			if(list.size()!=0) 
		       list.forEach(System.out::println);
			else
				System.out.println("Records not found");
				
		}
		catch(Exception e) {
			e.printStackTrace();
		}

	}

}
