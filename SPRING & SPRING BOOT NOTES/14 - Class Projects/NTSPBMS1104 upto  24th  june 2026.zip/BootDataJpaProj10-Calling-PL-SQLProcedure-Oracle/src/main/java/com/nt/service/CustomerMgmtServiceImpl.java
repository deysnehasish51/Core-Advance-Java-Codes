package com.nt.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nt.entity.Customer;

import jakarta.persistence.EntityManager;
import jakarta.persistence.ParameterMode;
import jakarta.persistence.StoredProcedureQuery;


@Service
public class CustomerMgmtServiceImpl implements ICustomerMgmtService {
	   @Autowired
        private  EntityManager  manager;
	   
		/*CREATE OR REPLACE PROCEDURE P_GET_CUSTOMERS_BY_BILLAMT 
		(
		  MINVAL IN NUMBER 
		, MAXVAL IN NUMBER 
		, DETAILS OUT SYS_REFCURSOR 
		) AS 
		BEGIN
		
		   OPEN DETAILS FOR
		       SELECT * FROM JPA_CUSTOMER_TAB WHERE CUST_BILL_AMT>=MINVAL AND CUST_BILL_AMT<=MAXVAL;
		
		END P_GET_CUSTOMERS_BY_BILLAMT;
		*/	   
	   
	@Override
	public List<Customer> showCustomerDetailsByBillAmtRange(double start, double end) {
		//create StoredProcedureQuery object
		StoredProcedureQuery query=manager.createStoredProcedureQuery("P_GET_CUSTOMERS_BY_BILLAMT",Customer.class);
		//register  both IN params and OUT params 
		query.registerStoredProcedureParameter(1, Integer.class,ParameterMode.IN);
		query.registerStoredProcedureParameter(2, Integer.class,ParameterMode.IN);
		query.registerStoredProcedureParameter(3, Integer.class,ParameterMode.REF_CURSOR);
		
		//  set values to IN params
		query.setParameter(1, start);
		query.setParameter(2, end);
		
		// call the PL/SQL procedure
		List<Customer>  list=query.getResultList();
		return list;
		
		}

}
