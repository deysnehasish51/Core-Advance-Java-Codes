package com.nt.service;

import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.nt.entity.College;
import com.nt.entity.Student;
import com.nt.repository.ICollegeRepository;
import com.nt.repository.IStudentRepository;

@Service
public class CollegeMgmtServiceImpl implements ICollegeMgmtService {
	@Autowired
	private  ICollegeRepository clgRepo;
	@Autowired
	private  IStudentRepository   studRepo;
	
  @Override
public List<Object[]> fetchCollegeAndStudentInfo() {
	  //use repo
	return clgRepo.showCollegeAndStudentsData();
}

@Override
public List<Object[]> fetchStudentsAndCollegesInfo() {
	return studRepo.showStudentsAndTheirCollege();
}
	

}
