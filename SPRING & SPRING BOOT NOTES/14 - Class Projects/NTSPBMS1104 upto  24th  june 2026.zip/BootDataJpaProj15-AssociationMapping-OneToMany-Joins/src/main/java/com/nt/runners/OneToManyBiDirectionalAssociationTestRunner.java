package com.nt.runners;

import java.util.Arrays;
import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import com.nt.entity.College;
import com.nt.entity.Student;
import com.nt.service.CollegeMgmtServiceImpl;
import com.nt.service.ICollegeMgmtService;

@Component
public class OneToManyBiDirectionalAssociationTestRunner implements CommandLineRunner {
	@Autowired
	private ICollegeMgmtService clgService;

	@Override
	public void run(String... args) throws Exception {
		/*try {
			List<Object[]> list=clgService.fetchCollegeAndStudentInfo();
			list.forEach(row->{
				System.out.println(Arrays.toString(row));
			});
		}
		catch(Exception e) {
			e.printStackTrace();
		}*/
		
		try {
			List<Object[]>  list=clgService.fetchStudentsAndCollegesInfo();
			list.forEach(row->{
				System.out.println(Arrays.toString(row));
			});
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		
	}

}
