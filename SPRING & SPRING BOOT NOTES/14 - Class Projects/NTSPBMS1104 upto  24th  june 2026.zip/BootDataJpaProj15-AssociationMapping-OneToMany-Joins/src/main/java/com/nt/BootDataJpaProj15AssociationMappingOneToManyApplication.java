package com.nt;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BootDataJpaProj15AssociationMappingOneToManyApplication {

	public static void main(String[] args) {
		SpringApplication.run(BootDataJpaProj15AssociationMappingOneToManyApplication.class, args);
	}

}
