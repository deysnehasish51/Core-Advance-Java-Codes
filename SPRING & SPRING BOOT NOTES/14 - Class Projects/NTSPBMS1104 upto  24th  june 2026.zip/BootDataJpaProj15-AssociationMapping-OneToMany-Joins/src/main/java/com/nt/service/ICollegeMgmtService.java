package com.nt.service;

import java.util.List;

import com.nt.entity.College;
import com.nt.entity.Student;

public interface ICollegeMgmtService {
	
    public  List<Object[]>  fetchCollegeAndStudentInfo();    
    public  List<Object[]>  fetchStudentsAndCollegesInfo();    
    
}
