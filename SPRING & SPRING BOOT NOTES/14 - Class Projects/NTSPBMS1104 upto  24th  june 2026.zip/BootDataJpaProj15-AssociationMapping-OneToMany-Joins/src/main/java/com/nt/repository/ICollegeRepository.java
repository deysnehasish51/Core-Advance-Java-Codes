package com.nt.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.nt.entity.College;

public interface ICollegeRepository  extends JpaRepository<College, Integer> {
	//@Query("select  c.cid,c.cname,c.caddrs,st.sno,st.sname,st.saddrs from College  c inner join c.studs  st")
	//@Query("select  c.cid,c.cname,c.caddrs,st.sno,st.sname,st.saddrs from College  c left join c.studs  st")
	//@Query("select  c.cid,c.cname,c.caddrs,st.sno,st.sname,st.saddrs from College  c right join c.studs  st")
	@Query("select  c.cid,c.cname,c.caddrs,st.sno,st.sname,st.saddrs from College  c full join c.studs  st")
	
     public  List<Object[]>  showCollegeAndStudentsData();
}
