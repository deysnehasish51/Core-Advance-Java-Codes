package com.nt.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.nt.entity.Student;

public interface IStudentRepository extends JpaRepository<Student, Integer> {

	//@Query("select  st.sno,st.sname,st.saddrs,c.cid,c.cname,c.caddrs from Student st inner join st.clg c")
	@Query("select  st.sno,st.sname,st.saddrs,c.cid,c.cname,c.caddrs from Student st left join st.clg c")
	
	public  List<Object[]>  showStudentsAndTheirCollege();
	
	
}

