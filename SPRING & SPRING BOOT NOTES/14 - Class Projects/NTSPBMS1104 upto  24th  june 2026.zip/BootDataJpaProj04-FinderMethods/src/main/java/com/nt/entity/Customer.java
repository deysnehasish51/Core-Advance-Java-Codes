//Customer.java
package com.nt.entity;

import org.hibernate.annotations.AnyDiscriminatorImplicitValues.Strategy;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;
import jakarta.persistence.Transient;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;

@Entity
@Table(name="JPA_CUSTOMER_TAB")
@Data
@NoArgsConstructor
@RequiredArgsConstructor
@AllArgsConstructor
public  class Customer {
	
	@Id
	@Column(name="CUST_ID")
	@SequenceGenerator(name="gen1",sequenceName = "CNO_SEQ1",initialValue = 2000,allocationSize = 1)
	@GeneratedValue(generator="gen1",strategy =GenerationType.SEQUENCE )
	private  Integer cno;
	
	@Column(name="CUST_NAME",length = 30)
	@NonNull
	private  String  cname;
	
	@Column(name="CUST_ADDRS",length = 30)
	@NonNull
	private  String  caddrs;
	
	@Column(name="CUST_BILL_AMT")
	@NonNull
	//@Transient
	private   Double billAmt;
}
