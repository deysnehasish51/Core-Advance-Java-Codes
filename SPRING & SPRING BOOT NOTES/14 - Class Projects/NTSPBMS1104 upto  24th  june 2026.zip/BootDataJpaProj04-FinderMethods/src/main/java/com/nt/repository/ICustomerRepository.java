package com.nt.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.transaction.annotation.Transactional;

import com.nt.entity.Customer;

public interface ICustomerRepository extends JpaRepository<Customer, Integer> {
     public  List<Customer>   findByCaddrsEquals(String addrs);
     public  List<Customer>   readByCaddrsIs(String addrs);
     
     public   Iterable<Customer>   getByCaddrs(String addrs);
     
     public   Iterable<Customer>  findByBillAmtBetween(double start,double end);
     
     public Iterable<Customer>   findByCnameStartingWith(String initChars);
     public Iterable<Customer>   findByCnameEndingWith(String lastChars);
     public Iterable<Customer>   findByCnameContaining(String chars);
     
     public Iterable<Customer>   findByCaddrsIn(List<String> addresses);
     public Iterable<Customer>   findByCaddrsInOrderByCnameDesc(List<String> addresses);
     
     public Iterable<Customer> findByBillAmtGreaterThanEqualAndBillAmtLessThanEqual(double min,double max);
     
     
     public  Iterable<Customer>  queryByCaddrsLikeOrCaddrsIsNull(String chars);
     
     public     long   countByBillAmtBetween(double start, double  end);
     public  boolean  existsByCnameEquals(String  name);
     
     @Transactional
     public   int  deleteByCaddrsIn(List<String>  cities);
         
}
