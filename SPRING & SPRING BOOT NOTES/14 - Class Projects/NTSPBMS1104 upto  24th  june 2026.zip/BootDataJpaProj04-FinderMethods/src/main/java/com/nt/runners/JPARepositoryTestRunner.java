package com.nt.runners;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import com.nt.entity.Customer;
import com.nt.repository.ICustomerRepository;

@Component
public class JPARepositoryTestRunner implements CommandLineRunner {
	@Autowired
	private  ICustomerRepository custRepo;
	
	@Override
	public void run(String... args) throws Exception {
	
		/* try {
			 //List<Customer>  list=custRepo.findByCaddrsEquals("hyd");
			// List<Customer>  list=custRepo.readByCaddrsIs("hyd");
			  Iterable<Customer>  list=custRepo.getByCaddrs("hyd");
			 list.forEach(System.out::println);
		 }
		catch(Exception e) {
			e.printStackTrace();
		}*/
		
		try {
			/*Iterable<Customer>  list=custRepo.findByBillAmtBetween(5000.0, 20000.0);
			list.forEach(System.out::println);
			*/	
			/*   Iterable<Customer>  list=custRepo.findByCnameStartingWith("r");
			 list.forEach(System.out::println);*/
			
			/*	custRepo.findByCnameEndingWith("a").forEach(System.out::println);
				System.out.println("------------------------");
				custRepo.findByCnameContaining("j").forEach(System.out::println);
			*/	
			// custRepo.findByCaddrsIn(List.of("hyd","vizag","delhi")).forEach(System.out::println);
			//custRepo.findByCaddrsInOrderByCnameDesc(List.of("hyd","vizag","delhi")).forEach(System.out::println);
			
			//custRepo.findByBillAmtGreaterThanEqualAndBillAmtLessThanEqual(3000.0, 10000.0).forEach(System.out::println);
			//custRepo.queryByCaddrsLikeOrCaddrsIsNull("h%").forEach(System.out::println);
			
			long  count=custRepo.countByBillAmtBetween(3000.0, 8000.0);
			System.out.println("records count  having billamt range 3000.0 and 8000.0 :::"+count);
			System.out.println("Is customer Customer exists with name raja "+custRepo.existsByCnameEquals("raja"));
			System.out.println("  no.of that  are deleted belonging to hyd,vizag,delhi"+custRepo.deleteByCaddrsIn(List.of("hyd","vizag","delhi")));
			
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		
		
		
		
	}
}
