package com.nt.entity;

import java.util.HashSet;
import java.util.Set;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;
import lombok.Setter;

@Entity
@Table(name="JPA_MTM_PATIENT")
@RequiredArgsConstructor
@Setter
@Getter
public class Patient {
	@Id
	@SequenceGenerator(name="gen1",sequenceName = "PID_SEQ",initialValue = 1000,allocationSize = 1)
    @GeneratedValue(generator = "gen1",strategy = GenerationType.SEQUENCE)	
	private   Integer pid;
     
	@Column(length = 30)
      @NonNull
	private  String pname;
	@Column(length = 30)
	@NonNull
	private  String paddrs;
	@Column(length = 30)
	@NonNull
	private  String problem;
	
	@ManyToMany(targetEntity = Doctor.class,
			                  cascade = CascadeType.ALL,
			                  fetch = FetchType.EAGER,
			                 mappedBy = "patients")
	private  Set<Doctor>  doctors=new HashSet<Doctor>();

	
	public Patient() {
		System.out.println("Patient:: 0-param constructor");
	}
	
	
	//toString  (alt+shift+s,s)
	@Override
	public String toString() {
		return "Patient [pid=" + pid + ", pname=" + pname + ", paddrs=" + paddrs + ", problem=" + problem + "]";
	}
	
	

}
