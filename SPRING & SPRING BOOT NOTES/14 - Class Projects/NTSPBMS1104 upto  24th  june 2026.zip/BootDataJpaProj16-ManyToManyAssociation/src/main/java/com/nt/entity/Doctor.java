//Doctor.java

package com.nt.entity;

import java.util.HashSet;
import java.util.Set;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.JoinTable;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;
import lombok.Setter;

@Entity
@Setter
@Getter
@RequiredArgsConstructor
@Table(name="JPA_MTM_DOCTOR")
public class Doctor {
	@Id
	@SequenceGenerator(name="gen1",sequenceName = "DID_SEQ",initialValue = 100,allocationSize = 1)
	@GeneratedValue(generator = "gen1",strategy = GenerationType.SEQUENCE)
	private  Integer did;

	@NonNull
	@Column(length = 30)
	private  String dname;
	
	@NonNull
	@Column(length = 30)
	private   String   qlfy;
	
	@NonNull
	@Column(length = 30)
	private    String specialization;
	
	@ManyToMany(targetEntity = Patient.class,cascade = CascadeType.ALL)
	@JoinTable(name="DOCTORS_PATIENTS",
	                      joinColumns = @JoinColumn(name="DOC_ID",referencedColumnName = "DID"),  //owning side FK column 
	                      inverseJoinColumns = @JoinColumn(name="PAT_ID",referencedColumnName = "PID"))  //non owning side FK column
	private Set<Patient>  patients=new HashSet<Patient>();
	
	public Doctor() {
		System.out.println("Doctor:: 0-param construtor"+this.getClass());
	}

	
	//toString()  (alt+shift+s,s)
	@Override
	public String toString() {
		return "Doctor [did=" + did + ", dname=" + dname + ", qlfy=" + qlfy + ", specialization=" + specialization
				+ "]";
	}
	

}
