package com.nt.runners;

import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import com.nt.entity.Doctor;
import com.nt.service.IDoctorMgmtService;

@Component
public class ManyToManyAssociationMappingTestRunner implements CommandLineRunner {
	@Autowired
	private IDoctorMgmtService doctorService;

	@Override
	public void run(String... args) throws Exception {
		/*	try {
				// prepare parents
				Doctor  doc1=new Doctor("raja","MBBS","physician");
				Doctor  doc2=new Doctor("suresh","MD","cardio");
				 //prepare childs
				Patient pat1=new Patient("anil","hyd","fever");
				Patient pat2=new Patient("mahesh","vizag","surgery");
				Patient pat3=new Patient("karan","delhi","cancer");
				//add  childs to parents
				doc1.getPatients().add(pat1); doc1.getPatients().add(pat2);
				doc2.getPatients().add(pat1); doc2.getPatients().add(pat2); doc2.getPatients().add(pat3);
				// add parents to childs
				pat1.getDoctors().add(doc1); pat1.getDoctors().add(doc2);
				pat2.getDoctors().add(doc1); pat2.getDoctors().add(doc2);
				pat3.getDoctors().add(doc2);
				
				// add doctors to List collection
				List<Doctor>  list=List.of(doc1,doc2);
				//invoke the method
				String  msg=doctorService.saveDoctorsAndPatients(list);
				System.out.println(msg);
				}
			catch(Exception e) {
				e.printStackTrace();
			}*/

		/*	try {
				// prepare parents
				Doctor  doc1=new Doctor("raja1","MBBS","physician");
				Doctor  doc2=new Doctor("suresh1","MD","cardio");
				 //prepare childs
				Patient pat1=new Patient("anil1","hyd","fever");
				Patient pat2=new Patient("mahesh1","vizag","surgery");
				Patient pat3=new Patient("karan1","delhi","cancer");
				Patient pat4=new Patient("ramana","delhi","bone");
				
				//add  childs to parents
				doc1.getPatients().add(pat1); doc1.getPatients().add(pat2);doc1.getPatients().add(pat4);
				doc2.getPatients().add(pat1); doc2.getPatients().add(pat2); doc2.getPatients().add(pat3);
				// add parents to childs
				pat1.getDoctors().add(doc1); pat1.getDoctors().add(doc2);
				pat2.getDoctors().add(doc1); pat2.getDoctors().add(doc2);
				pat3.getDoctors().add(doc2); 
				pat4.getDoctors().add(doc1);
				
				// add doctors to List collection
				List<Patient>  list=List.of(pat1,pat2,pat3,pat4);
				//invoke the method
				String  msg=doctorService.savePatientsAndDoctors(list);
				System.out.println(msg);
				}
			catch(Exception e) {
				e.printStackTrace();
			}
		*/

		/*try {
			doctorService.showDoctorsAndTheirPateints().forEach(doc->{
				   System.out.println("Doctor (parent)"+doc);
				   Set<Patient>  patients=doc.getPatients();
				   patients.forEach(pat->{
				  	 System.out.println("Patient(child)"+pat);
				   });
			             System.out.println("--------------------");
			});
		}
		catch(Exception e) {
			e.printStackTrace();
		}*/
		try {
			doctorService.showPatientsAndTheirDoctors().forEach(pat->{
				System.out.println("Patient (child)::"+pat);
				Set<Doctor>  doctors=pat.getDoctors();
				doctors.forEach(doc->{
					System.out.println("Doctor (parent)::"+doc);
				});
				System.out.println("------------------");
			});
			
		}
		catch(Exception e) {
			e.printStackTrace();
		}

	}

}
