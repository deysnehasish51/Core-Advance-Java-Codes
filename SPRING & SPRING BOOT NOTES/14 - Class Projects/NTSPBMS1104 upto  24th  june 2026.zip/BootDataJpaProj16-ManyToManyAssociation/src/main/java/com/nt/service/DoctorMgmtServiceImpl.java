package com.nt.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nt.entity.Doctor;
import com.nt.entity.Patient;
import com.nt.repository.IDoctorRepository;
import com.nt.repository.IPatientRepository;

@Service
public class DoctorMgmtServiceImpl implements IDoctorMgmtService {
	@Autowired
	private IDoctorRepository  doctorRepo;
	@Autowired
	private   IPatientRepository patientRepo;
	

	@Override
	public String saveDoctorsAndPatients(List<Doctor> list) {
		//use repo
		  List<Doctor>  savedList=doctorRepo.saveAll(list);
		  //get  saved ids
		  List<Integer> ids=savedList.stream().map(Doctor::getDid).toList();
		  
		return ids+"  doctors are saved along with the associated patients";
	}


	@Override
	public String savePatientsAndDoctors(List<Patient> list) {
		//use repo
		  List<Patient>  savedList=patientRepo.saveAll(list);
		  //get  saved ids
		  List<Integer> ids=savedList.stream().map(Patient::getPid).toList();
		  
		return ids+"  Patients are saved along with the associated doctors";
	
	}
	
	@Override
	public List<Doctor> showDoctorsAndTheirPateints() {
		return  doctorRepo.findAll();
	}
	
	@Override
	public List<Patient> showPatientsAndTheirDoctors() {
		return patientRepo.findAll();
	}

}
