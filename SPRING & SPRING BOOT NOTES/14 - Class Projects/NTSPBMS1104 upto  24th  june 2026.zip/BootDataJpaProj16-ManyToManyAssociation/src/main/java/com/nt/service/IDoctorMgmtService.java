package com.nt.service;

import java.util.List;

import com.nt.entity.Doctor;
import com.nt.entity.Patient;

public interface IDoctorMgmtService {
    public  String  saveDoctorsAndPatients(List<Doctor> list);
    public  String  savePatientsAndDoctors(List<Patient> list);
    public  List<Doctor> showDoctorsAndTheirPateints();
    public  List<Patient> showPatientsAndTheirDoctors();
    
     
}
