package com.nt;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BootDataJpaProj16ManyToManyAssociationApplicationTests {

	@Test
	void contextLoads() {
	}

}
