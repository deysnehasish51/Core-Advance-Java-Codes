//RecieverApp.java
package com.nt.reciever;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Component;

import com.nt.model.Employee;

@Component
public class RecieverApp  {
	   private Employee emp;
	
	@KafkaListener(topics = "tpc2",groupId ="grp2")
	public void readMessage(Employee emp) {
          this.emp=emp;
		System.out.println("The recieved message is ::"+emp);
		
	}
	
	public   Employee  showCurrentMessage() {
		return emp;
	}
	
	
}
