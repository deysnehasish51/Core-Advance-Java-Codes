//SenderApp.java
package com.nt.sender;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Component;

import com.nt.model.Employee;

@Component
public class SenderApp  {
	@Autowired
   private KafkaTemplate<String, Employee>  template;
	
	public String send(Employee emp) throws Exception {
		template.send("tpc2", "emp Info",new Employee(101,"raja","hyd"));
		return  "message is sent";		
		
	}
	
	
}
