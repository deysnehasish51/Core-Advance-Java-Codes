package com.nt.rest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.nt.model.Employee;
import com.nt.reciever.RecieverApp;
import com.nt.sender.SenderApp;

@RestController
@RequestMapping("/employee-api")
public class EmloyeeOperationsRestController {
	@Autowired
	private SenderApp  sender;
	@Autowired
	private  RecieverApp  reciever;
	
	@PostMapping("/send")
	public   ResponseEntity<String>  sendMessage(@RequestBody   Employee emp)throws Exception{
		//use service
		String  msg=sender.send(emp);
		//returne  ResponseEntity object
		return new ResponseEntity<String>(msg, HttpStatus.OK);
	}
	
	@GetMapping("/read")
	public   ResponseEntity<Employee>  readMessage()throws Exception{
	      //use service
		Employee emp=reciever.showCurrentMessage();
		//return  RE
		return new ResponseEntity<Employee>(emp,HttpStatus.OK);
	}

}
