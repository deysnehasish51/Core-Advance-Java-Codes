package com.nt.runners;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import com.nt.entity.BankAccount;
import com.nt.service.IBankMgmtService;

@Component
public class VersioningAndTimestampTestRunner implements CommandLineRunner {
	@Autowired
	private  IBankMgmtService  bankService;

	@Override
	public void run(String... args) throws Exception {
	//invoke the method
	/*	try {
			BankAccount  account=new BankAccount("raja","hyd",5700.0);
			String msg=bankService.openBankAccount(account);
			System.out.println(msg);
			System.out.println("----------------------------------------");
			BankAccount account1=bankService.showBankAccountDetailsByAcno(10000003);
			System.out.println(account1);
			System.out.println("account is opened on ::"+account.getCreatedOn());
			System.out.println("account is last accessed on:: "+account.getUpdatedOn());
			System.out.println("account  details are modified for ::"+account.getUpdateCount());
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	*/	
	/*	try {
			String msg=bankService.withdrawAmount(10000003, 200.0);
			System.out.println(msg);
			System.out.println("------------------------");
			BankAccount account1=bankService.showBankAccountDetailsByAcno(10000003);
			System.out.println(account1);
			System.out.println("account is opened on ::"+account1.getCreatedOn());
			System.out.println("account is last accessed on:: "+account1.getUpdatedOn());
			System.out.println("account  details are modified for ::"+account1.getUpdateCount());
		}
		catch(Exception e) {
			e.printStackTrace();
		}*/
		
		try {
			 BankAccount  account=new BankAccount();
			 account.setAcno(10000003L);
			 account.setHolderName("raja");
			 account.setBranch("hyd");
			 account.setBalance(80000.0);
			String msg=bankService.updateAccountDetails(account);
			System.out.println(msg);
		}
		catch(Exception e ) {
			e.printStackTrace();
		}
		
	}

}
