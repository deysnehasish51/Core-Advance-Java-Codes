//BankAccount.java
package com.nt.entity;

import java.time.LocalDateTime;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Version;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@RequiredArgsConstructor
public class BankAccount {
	  //Data properties
	@Id
	@SequenceGenerator(name="gen1",sequenceName = "ACNO_SEQ",initialValue = 10000000,allocationSize = 1)
	@GeneratedValue(generator = "gen1",strategy = GenerationType.SEQUENCE)
    private  Long acno;
	
	@Column(length=30)
    @NonNull
	private   String   holderName;
	@Column(length = 30)
	@NonNull
    private  String branch;
	@NonNull
    private  Double balance;
    
    // MetaData Properties
    @Column(length = 30,insertable = true)
    private  String  createdBy;
    @Column(length = 30,updatable = true)
    private   String updatedBy;
    @Version
    private   Integer  updateCount;
    
    @CreationTimestamp
    @Column(insertable = true )
    private  LocalDateTime  createdOn;
    @UpdateTimestamp
    @Column(updatable=true)
    private  LocalDateTime updatedOn;
    @Column(length = 30)
    private  String active_SW="active";
    
    
}
