package com.nt;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BootDataJpaProj06VersoningTimeStampingApplication {

	public static void main(String[] args) {
		SpringApplication.run(BootDataJpaProj06VersoningTimeStampingApplication.class, args);
	}

}
