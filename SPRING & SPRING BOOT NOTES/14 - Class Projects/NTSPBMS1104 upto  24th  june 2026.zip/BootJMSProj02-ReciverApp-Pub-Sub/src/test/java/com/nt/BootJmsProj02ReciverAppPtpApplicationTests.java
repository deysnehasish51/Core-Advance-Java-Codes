package com.nt;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BootJmsProj02ReciverAppPtpApplicationTests {

	@Test
	void contextLoads() {
	}

}
