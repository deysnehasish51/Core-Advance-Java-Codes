package com.nt.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.nt.entity.Employee;

public interface IEmployeeRepository extends JpaRepository<Employee, Integer> {

	@Query("Select e from Employee e  inner join e.phones p where  p in(:ph1,:ph2)")
	public  List<Employee>  showEmployeesByPhones(long ph1,long ph2);
}
