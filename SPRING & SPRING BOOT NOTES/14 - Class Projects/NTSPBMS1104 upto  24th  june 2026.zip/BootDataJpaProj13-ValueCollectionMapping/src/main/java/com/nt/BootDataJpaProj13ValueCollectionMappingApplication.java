package com.nt;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BootDataJpaProj13ValueCollectionMappingApplication {

	public static void main(String[] args) {
		SpringApplication.run(BootDataJpaProj13ValueCollectionMappingApplication.class, args);
	}

}
