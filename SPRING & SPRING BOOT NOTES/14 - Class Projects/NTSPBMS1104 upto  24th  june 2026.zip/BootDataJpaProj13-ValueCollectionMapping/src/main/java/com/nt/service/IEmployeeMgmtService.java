package com.nt.service;

import java.util.List;

import com.nt.entity.Employee;

public interface IEmployeeMgmtService {
     public  String  saveEmployee(Employee emp);
     public   List<Employee>  showAllEmployees();
     public   List<Employee>  showEmployeesByPhones(long ph1,long ph2);
     public   String     removePhoneNumberFromEmployee(int eno,long phone);
     public  String   addNewFavColorToEmployee(int eno,String color);
     

}
