package com.nt.runners;

import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import com.nt.entity.Employee;
import com.nt.repository.IEmployeeRepository;
import com.nt.service.IEmployeeMgmtService;

@Component
public class CollectionMappingTestRunner implements CommandLineRunner {
	@Autowired
	private  IEmployeeMgmtService  empService;

	@Override
	public void run(String... args) throws Exception {
		//save the object
		/*	Employee  emp=new Employee("suresh","hyd");
			emp.setFavColors(List.of("blue", "yellow","green"));
			emp.setPhones(Set.of(999999999999L,77777771L,4545454551L,354545454451L));
			emp.setIdDetails(Map.of("aadhar",54541454L, "pan", 515665565L));
			
			try {
				String msg=empService.saveEmployee(emp);
				System.out.println(msg);
			}
			catch(Exception e) {
				e.printStackTrace();
			}
		*/	
		
		/*	try {
				empService.showAllEmployees().forEach(System.out::println);
			}
			catch(Exception e) {
				e.printStackTrace();
			}*/
		
		/*try {
			List<Employee>  list=empService.showEmployeesByPhones(77777777L, 999999999999L);
			list.forEach(System.out::println);
		}
		catch(Exception e) {
			e.printStackTrace();
		}*/
		
				try {
					String msg=empService.removePhoneNumberFromEmployee(100, 77777777L);
					System.out.println(msg);
				}
				catch(Exception e) {
					e.printStackTrace();
				}
		
		
		try {
			String msg=empService.addNewFavColorToEmployee(100, "yellow");
			System.out.println(msg);
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		

	}

}
