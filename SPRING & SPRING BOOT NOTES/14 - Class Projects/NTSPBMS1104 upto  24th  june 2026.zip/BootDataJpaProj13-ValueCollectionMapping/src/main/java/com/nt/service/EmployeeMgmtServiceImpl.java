package com.nt.service;

import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nt.entity.Employee;
import com.nt.repository.IEmployeeRepository;

@Service
public class EmployeeMgmtServiceImpl implements IEmployeeMgmtService {
	@Autowired
   private IEmployeeRepository  empRepo;	

	@Override
	public String saveEmployee(Employee emp) {
	    //save the object
		int idVal=empRepo.save(emp).getEmpno();
		
		return "Employee object is saved with id Value:"+idVal;
	}

	@Override
	public List<Employee> showAllEmployees() {
		return empRepo.findAll();
	}

	@Override
	public List<Employee> showEmployeesByPhones(long ph1, long ph2) {
		//use repo
		List<Employee>  list=empRepo.showEmployeesByPhones(ph1, ph2);
		return list;
	}
	
	@Override
	public String removePhoneNumberFromEmployee(int eno, long phone) {
		//Load the  employee
		Employee emp=empRepo.findById(eno).orElseThrow(()->new IllegalArgumentException("Invalid Id"));
		// get All phones
		Set<Long>   phones=emp.getPhones();
		//remove  given phone  nubmer from the collection
		phones.remove(phone);
		//update the employee object
		empRepo.save(emp);
		
		  return  phone+"  Phone Number is removed from "+eno+" employee";
	}

	@Override
	public String addNewFavColorToEmployee(int eno, String color) {
		//Load the  employee
		Employee emp=empRepo.findById(eno).orElseThrow(()->new IllegalArgumentException("Invalid Id"));
		// get the existing favColors of the Employee
    	List<String>   favColors=emp.getFavColors();
    	//add new fav Color
    	favColors.add(color);
    	//update the object
            empRepo.save(emp);
		return color+" color is added to "+eno+" employee";
	}
	
	
}
