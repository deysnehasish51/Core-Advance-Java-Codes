package com.nt.entity;

import java.util.List;
import java.util.Map;
import java.util.Set;

import jakarta.persistence.CollectionTable;
import jakarta.persistence.Column;
import jakarta.persistence.ElementCollection;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.MapKeyColumn;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;

@Data
@RequiredArgsConstructor
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name="EMPLOYEE_TAB")
public class Employee {
   @Id
   @SequenceGenerator(name="gen1",sequenceName = "EMPNO_SEQ",initialValue = 100 ,allocationSize = 1)
   @GeneratedValue(generator = "gen1",strategy = GenerationType.SEQUENCE)
	private  Integer empno;
   @NonNull
   @Column(length = 30)
   private  String ename;
   @NonNull
   @Column(length = 30)
   private  String  eaddrs;
   
   //Collection properties
   @ElementCollection
   @Column(name="fav_colors")                               
   
   @CollectionTable(name="EMP_FavColors",
                                     joinColumns = @JoinColumn(name="EMP_ID",referencedColumnName = "EMPNO"))
   private List<String> favColors;
   
   @ElementCollection
   @Column(name="contant_no")                               
    @CollectionTable(name="EMP_phones",
                                     joinColumns = @JoinColumn(name="EMP_ID",referencedColumnName = "EMPNO"))
   private  Set<Long>  phones;
   
   @ElementCollection
   @Column(name="ID_VALUE")                               
    @CollectionTable(name="EMP_ID_DETAILS",
                                     joinColumns = @JoinColumn(name="EMP_ID",referencedColumnName = "EMPNO"))
   @MapKeyColumn(name = "ID_NAME")
   private  Map<String,Long>  idDetails;
   
   
   
}
