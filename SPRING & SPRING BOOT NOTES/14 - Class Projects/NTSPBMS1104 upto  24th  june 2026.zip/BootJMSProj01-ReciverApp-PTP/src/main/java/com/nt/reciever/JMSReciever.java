package com.nt.reciever;

import org.springframework.jms.annotation.JmsListener;
import org.springframework.stereotype.Component;

@Component
public class JMSReciever {

	@JmsListener(destination = "mq1")
	public  void   readMessage(String msg) {
		System.out.println("The message is ::"+msg);
	}
}
