package com.nt.service;

import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.nt.entity.College;
import com.nt.entity.Student;
import com.nt.repository.ICollegeRepository;
import com.nt.repository.IStudentRepository;

@Service
public class CollegeMgmtServiceImpl implements ICollegeMgmtService {
	@Autowired
	private  ICollegeRepository clgRepo;
	@Autowired
	private  IStudentRepository   studRepo;
	

	@Override
	public String saveCollegeAndItsStudents(College college) {
	  //save  parent  object and the associated child objects
		int idVal=clgRepo.save(college).getCid();
		return "College object and its  associated  Child objects are saved with id value ::"+idVal;
	}


	@Override
	public String saveStudentsAndTheirCollege(List<Student> list) {
		//save the objects
		Iterable<Student>  savedList=studRepo.saveAll(list);
		// gather the id values  of the saved List
		List<Integer>  ids=StreamSupport.stream(savedList.spliterator(), false).map(Student::getSno).collect(Collectors.toList());
		
		return   ids.size()+"  no.of  Students ant their college info is saved with id Values ::"+ids;
	}
	
	@Override
	public Iterable<College> showCollegesAndTheirStudents() {
		Iterable<College>  list=clgRepo.findAll();
		return list;
	}
	
	@Override
	public Iterable<Student> showStudentsAndTheirColleges() {
		return studRepo.findAll();
	}


	@Override
	public College showCollegeAndItsStudent(int cid) {
		return clgRepo.findById(cid).orElseThrow(()->new IllegalArgumentException("Invalid Id"));
	}
	
	@Override
	public String removeCollegeAndItsStudents(int cid) {
		//Load  parent object
		College college=clgRepo.findById(cid).orElseThrow(()->new IllegalArgumentException("Invalid Id"));
		//remove  parent  and its childs
		clgRepo.delete(college);
		return cid+"College  and its childs are deleted";
	}
	
	@Override
	public String removeStudentsAndTheirCollege(int sno1, int sno2) {
		//Load childs by Ids
		List<Student> list=studRepo.findAllById(List.of(sno1,sno2));
		//delete the objects
		studRepo.deleteAll(list);
		
		return sno1+","+sno2+" Students and their College is deleted";
	}
	
	@Override
	public String addNewStudentToCollege(Student st, int cid) {
	    //From parent prospective
		 
		  //Load  the College Object
		College college=clgRepo.findById(cid).orElseThrow(()-> new IllegalArgumentException("Invalid College ID"));
		// Link college with  student
		st.setClg(college);
		// get  existing students
		Set<Student>  studs=college.getStuds();
		//add new student to the collection
		studs.add(st);
		//update the object
		college.setStuds(studs);
		 clgRepo.save(college);
		return " Student is added to "+cid+"College";
	}
	
	@Override
	public String transferStudentToAnotherCollege(int sid, int srcCno, int destCno) {
		//Load  Source College object
		College  SrcCollege=clgRepo.findById(srcCno).orElseThrow(()->new IllegalArgumentException("Invalid Id"));
		//Load  Dest College object
		College  destCollege=clgRepo.findById(destCno).orElseThrow(()->new IllegalArgumentException("Invalid Id"));
		//Load the Student object
		Student st=studRepo.findById(sid).orElseThrow(()->new IllegalArgumentException("Invalid SID"));
		// change the college  of the student
		st.setClg(destCollege);
		//update the Student
		studRepo.save(st);
		return   sid+" Student is trasfered from "+srcCno+" college to "+destCno+" College";
	}


	@Override
	public String removeAllStudentsFromACollege(int cno) {
		//Load  the College
		College  college=clgRepo.findById(cno).orElseThrow(()->new IllegalArgumentException("Invalid Id"));
		//get  all the students of a College
		Set<Student> studs=college.getStuds();
		//make childs not pointing to parent
		studs.forEach(st->{
			st.setClg(null);
		});
		//delete the childs
		studRepo.deleteAllInBatch(studs);
		
		return  "all the students ("+studs.size()+")  of  "+cno+" college  are removed";
	}
	
	@Override
	@Transactional
	public String removeAStudentFromACollege(int sno, int cno) {
		//Load the Student object
		Student stud=studRepo.findById(sno).orElseThrow(()->new IllegalArgumentException("Invalid SID"));
		//remove  colleg from student
		stud.setClg(null);
		//delete the Student
		studRepo.save(stud);
		studRepo.delete(stud);
		return sno+" Student is  removed from "+cno+" College";
	}

}
