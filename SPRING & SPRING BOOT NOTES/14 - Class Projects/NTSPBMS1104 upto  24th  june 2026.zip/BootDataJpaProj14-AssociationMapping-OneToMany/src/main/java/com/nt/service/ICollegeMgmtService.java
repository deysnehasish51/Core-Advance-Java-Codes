package com.nt.service;

import java.util.List;

import com.nt.entity.College;
import com.nt.entity.Student;

public interface ICollegeMgmtService {
    public  String  saveCollegeAndItsStudents(College  college);
    public  String   saveStudentsAndTheirCollege(List<Student> list);
    public  Iterable<College>  showCollegesAndTheirStudents();
    public   Iterable<Student>  showStudentsAndTheirColleges();
    public   College  showCollegeAndItsStudent(int cid);
    public  String  removeCollegeAndItsStudents(int cid);
    public  String  removeStudentsAndTheirCollege(int sno1, int sno2);
    
    public  String addNewStudentToCollege(Student st,int cid);
    public String   transferStudentToAnotherCollege(int  sid,int srcCno, int destCno);
    public String  removeAllStudentsFromACollege(int cno);
    public  String  removeAStudentFromACollege(int sno,int cno);
    
}
