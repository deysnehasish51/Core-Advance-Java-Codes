package com.nt.runners;

import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import com.nt.entity.College;
import com.nt.entity.Student;
import com.nt.service.CollegeMgmtServiceImpl;
import com.nt.service.ICollegeMgmtService;

@Component
public class OneToManyBiDirectionalAssociationTestRunner implements CommandLineRunner {
	@Autowired
	private ICollegeMgmtService clgService;

	@Override
	public void run(String... args) throws Exception {
		/*try {
			//prepare Parent object
			College clg=new College("KMIT","hyd");
			//prepare  child objs
			Student  st1=new Student("mahesh","hyd");
			Student  st2=new Student("lokesh","BBSR");
			
			//set parent to childs
			st1.setClg(clg); st2.setClg(clg);
			//set childs to parents
			clg.setStuds(Set.of(st1,st2));
			
			//save the objects
			String  msg=clgService.saveCollegeAndItsStudents(clg);
			System.out.println(msg);
			
		}
		catch(Exception e) {
			e.printStackTrace();
		}*/
		
				
				
		/*try {
			//prepare Parent object
			College clg=new College("RGIET","hyd");
			//prepare  child objs
			Student  st1=new Student("subash","hyd");
			Student  st2=new Student("naresh","BBSR");
			//map  parent with childs
			st1.setClg(clg); st2.setClg(clg);
			//mapping childs to parent
			clg.setStuds(Set.of(st1,st2));
			//add   childs to List Collection
			List<Student> list=List.of(st1,st2);
			//invoke the method
			String msg=clgService.saveStudentsAndTheirCollege(list);
			System.out.println(msg);
		}
		catch(Exception e) {
		   e.printStackTrace();
		}*/
		
		/*try {
			Iterable<College>  list=clgService.showCollegesAndTheirStudents();
			list.forEach(clg->{
				System.out.println("Parent (college)::"+clg);
				Set<Student> childs=clg.getStuds();
				childs.forEach(st->{
					System.out.println("Child (Student)::"+st);
				});
				System.out.println("------------------------");
			});*/
			
			
			/*		try {
						Iterable<Student>  list=clgService.showStudentsAndTheirColleges();
						list.forEach(st->{
							System.out.println("Child (Student)::"+st);
							College college=st.getClg();
							System.out.println("Parent (College)::"+college);
							System.out.println("-----------------------------------------");
							
						});
					}
					catch(Exception e) {
						e.printStackTrace();
					}*/
			
			/*try {
				College college=clgService.showCollegeAndItsStudent(1002);
				System.out.println("Parent ::"+college);
				Set<Student>  studs=college.getStuds();
			     studs.forEach(st->System.out.println("Child ::"+st));
			}
			catch(Exception e) {
				e.printStackTrace();
			}
			
		}
		catch(Exception e) {
			e.printStackTrace();
		}
*/		
			
			/*	try {
					String msg=clgService.removeCollegeAndItsStudents(1001);
					System.out.println(msg);
				}
				catch(Exception e) {
					e.printStackTrace();
				}*/
			
			
			/*			try {
							String msg=clgService.removeStudentsAndTheirCollege(5, 7);
							System.out.println(msg);
						}
						catch(Exception e) {
							e.printStackTrace();
						}
			*/
		
			/*	try {
					Student st=new Student("karuna", "delhi");
					String msg=clgService.addNewStudentToCollege(st, 1004);
					System.out.println(msg);
				}
				catch(Exception e) {
					e.printStackTrace();
				}*/
		
			/*try{
				Student st=new Student("apoorva", "chennai");
			   String msg= clgService.addNewStudentToCollege(st, 1005);	
			   System.out.println(msg);
			}
			catch(Exception e) {
				e.printStackTrace();
			}*/
		
			/*try {
				String  msg=clgService.transferStudentToAnotherCollege(13, 1004, 1005);
				System.out.println(msg);
			}
			catch(Exception e) {
				e.printStackTrace();
			}*/
		
			/*	try {
					String msg=clgService.removeAllStudentsFromACollege(1005);
					System.out.println(msg);
				}
				catch(Exception e) {
					e.printStackTrace();
				}*/
		
		try {
			String msg=clgService.removeAStudentFromACollege(10, 1004);
			System.out.println(msg);
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		
		
	}

}
