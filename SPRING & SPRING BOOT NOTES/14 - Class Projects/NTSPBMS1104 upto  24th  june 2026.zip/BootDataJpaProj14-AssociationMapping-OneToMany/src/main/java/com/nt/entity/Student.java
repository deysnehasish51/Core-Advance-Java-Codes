package com.nt.entity;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;
import lombok.Setter;

@Entity
@Table(name="JPA_OTM_STUDENT")
@Setter
@Getter
@RequiredArgsConstructor
public class Student {
	@Id
	@SequenceGenerator(name="gen1",sequenceName = "SNO_ID",initialValue = 1,allocationSize = 1 )
	@GeneratedValue(generator = "gen1",strategy = GenerationType.SEQUENCE)
	private  Integer sno;
	
	@Column(length = 30)
	@NonNull
	private  String  sname;
	@Column(length = 30)
	@NonNull
	private  String  saddrs;
	
	@ManyToOne(targetEntity = College.class, cascade = CascadeType.ALL,fetch = FetchType.EAGER)
	@JoinColumn(name="CLG_ID",referencedColumnName = "CID")
	private  College  clg;  //for  building Many To One Association
	
	public Student() {
		System.out.println("Student:: 0-param constructor:::"+this.getClass());
	}

	
	//toString() alt+shift+s,s
	@Override
	public String toString() {
		return "Student [sno=" + sno + ", sname=" + sname + ", saddrs=" + saddrs + "]";
	}
	

}
