//College.java
package com.nt.entity;

import java.util.Set;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToMany;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;
import lombok.Setter;

@Entity
@Table(name="JPA_OTM_COLLEGE")
@Setter
@Getter
@RequiredArgsConstructor
public class College {
   @SequenceGenerator(name="gen1",sequenceName = "CID_SEQ1",initialValue = 1000,allocationSize = 1)
   @GeneratedValue(generator = "gen1",strategy =GenerationType.SEQUENCE)
   @Id
	private  Integer cid;
   
   @Column(length = 30)
	@NonNull
   private  String  cname;
   
   @Column(length = 30)
   @NonNull
   private   String  caddrs;
   
    @OneToMany(targetEntity = Student.class,cascade = CascadeType.ALL,mappedBy = "clg",
    		                     fetch = FetchType.EAGER,orphanRemoval = true)	
    //@JoinColumn(name="CLG_ID",referencedColumnName = "CID")
	private Set<Student>  studs;  //For  building one to Many Association

    public College() {
		System.out.println("College:: 0-param constructor:::"+this.getClass());
	}
    
	@Override
	public String toString() {
		return "College [cid=" + cid + ", cname=" + cname + ", caddrs=" + caddrs + "]";
	}
    
    
    
    
}
