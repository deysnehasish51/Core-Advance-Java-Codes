package com.nt;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BootKafkaProj02RecieverAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
