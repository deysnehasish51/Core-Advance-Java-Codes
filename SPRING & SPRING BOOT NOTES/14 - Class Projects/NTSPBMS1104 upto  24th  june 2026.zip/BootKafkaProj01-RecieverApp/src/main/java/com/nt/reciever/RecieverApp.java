package com.nt.reciever;

import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Component;

@Component
public class RecieverApp {
	
	@KafkaListener(topics = "tpc1",groupId = "grp2")
	public void  readMessage(String text) {
		System.out.println("Reciever--> the message is ::"+text);
	}

}
