package com.nt.runners;

import java.io.FileOutputStream;
import java.io.FileWriter;
import java.util.Scanner;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import com.nt.entity.JobSeeker;
import com.nt.service.IJobSeekerMgmtService;

@Component
public class LOBsTestRunner1 implements CommandLineRunner {
	@Autowired
	private  IJobSeekerMgmtService  jobService;

	@Override
	public void run(String... args) throws Exception {
		        
		   // create Scanner object
		try(Scanner  sc=new Scanner(System.in)){
			  System.out.println("Enter JobSeeker Id");
			  int  no=sc.nextInt();
			  //invoke the method
			  JobSeeker js=jobService.showJobSeekerById(no);
			  //get the data
			  System.out.println(js.getJsId()+"..."+js.getJsName()+"..."+js.getJsAddrs());
			  //  get byte[] representing photoContent
			  byte[] photoContent=js.getPhoto();
			//  get char[] representing resumeContent
			  char[]   resumeContent=js.getResume();
			  
			//write  byte[]  content to  image  file
			  try(FileOutputStream fos=new FileOutputStream("new_photo.gif")){
				    fos.write(photoContent);
			  }
				//write  char[]  content to  text file
			  try(FileWriter  writer=new FileWriter("new_resume.txt")){
				    writer.write(resumeContent);
			  }
			System.out.println("Photo content , resume content are written  files");		  
		}//try
		catch(Exception e) {
			e.printStackTrace();
		}
		

	}//main
}//class
