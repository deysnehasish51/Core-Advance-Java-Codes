package com.nt.runners;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.util.Scanner;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import com.nt.entity.JobSeeker;
import com.nt.service.IJobSeekerMgmtService;

//@Component
public class LOBsTestRunner implements CommandLineRunner {
	@Autowired
	private  IJobSeekerMgmtService  jsService;

	@Override
	public void run(String... args) throws Exception {
		try(Scanner sc=new Scanner(System.in);){
			    System.out.println("Enter  job seeker name::");
			    String  jsName=sc.next();
			    System.out.println("Enter job seeker address::");
			    String addrs=sc.next();
			    System.out.println("Enter job Seeker  photo file path::");
			    String photoPath=sc.next().trim();
			    System.out.println("Enter job Seeker  resume file path::");
			    String resumePath=sc.next().trim();
			    
			    //convert photo File content to byte[]
			    byte[]  photoContent=null;
			    try(FileInputStream  fis=new FileInputStream(photoPath)){
			    	   photoContent=fis.readAllBytes();
			    }
			    
			    //convert  resume file content to  char[]
			    File file=new File(resumePath);
			    char[]  resumeContent=new char[(int)file.length()];
			    try(FileReader reader=new FileReader(resumePath)){
			          reader.read(resumeContent);	 
			    }
			    
			    //create Entity class object
			    JobSeeker  js=new JobSeeker();
			    js.setJsName(jsName);
			    js.setJsAddrs(addrs);
			    js.setPhoto(photoContent);
			    js.setResume(resumeContent);
			    //invoke the service class method
			    String msg=jsService.registerJobSeeker(js);
			    System.out.println(msg);
		}
		catch(Exception e) {
			e.printStackTrace();
		}

	}

}
