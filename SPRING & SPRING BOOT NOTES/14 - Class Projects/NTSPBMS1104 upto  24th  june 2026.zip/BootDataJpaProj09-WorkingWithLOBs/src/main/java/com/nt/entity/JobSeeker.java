package com.nt.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Lob;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;

@Entity
@Data
@RequiredArgsConstructor
@NoArgsConstructor
@AllArgsConstructor
@Table(name="JOB_SEEKER_TAB")
public class JobSeeker {
	@Id
	@SequenceGenerator(name="gen1",sequenceName = "JSID_SEQ10",allocationSize = 1,initialValue = 100)
	@GeneratedValue(generator = "gen1",strategy = GenerationType.SEQUENCE)
	private  Integer jsId;
	@NonNull
	@Column(length = 30)
	private  String jsName;
	@NonNull
	@Column(length = 30)
	private  String  jsAddrs;
	@NonNull
	@Lob
	private  byte[]   photo;
	@NonNull
	@Lob
	private  char[]  resume;  

}
