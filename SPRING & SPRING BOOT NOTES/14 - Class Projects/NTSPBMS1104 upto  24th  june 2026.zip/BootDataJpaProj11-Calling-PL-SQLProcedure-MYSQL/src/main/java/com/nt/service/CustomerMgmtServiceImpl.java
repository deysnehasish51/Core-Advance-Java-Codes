package com.nt.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nt.entity.Customer;

import jakarta.persistence.EntityManager;
import jakarta.persistence.ParameterMode;
import jakarta.persistence.StoredProcedureQuery;


@Service
public class CustomerMgmtServiceImpl implements ICustomerMgmtService {
	   @Autowired
       
	   private  EntityManager  manager;
	   
	
		/*CREATE DEFINER=`root`@`localhost` PROCEDURE `P_GET_CUSTOMERS_BY_BILLAMT`(in start float , in stop float )
			   BEGIN
		
			     select  *  from  JPA_CUSTOMER_TAB WHERE CUST_BILL_AMT>=start AND  CUST_BILL_AMT<=stop; 
		
			   END
		*/	   
	   
	@Override
	public List<Customer> showCustomerDetailsByBillAmtRange(double start, double end) {
		//create StoredProcedureQuery object
		StoredProcedureQuery query=manager.createStoredProcedureQuery("P_GET_CUSTOMERS_BY_BILLAMT",Customer.class);
		//register  both IN params and OUT params 
		query.registerStoredProcedureParameter(1, Integer.class,ParameterMode.IN);
		query.registerStoredProcedureParameter(2, Integer.class,ParameterMode.IN);
		
		//  set values to IN params
		query.setParameter(1, start);
		query.setParameter(2, end);
		
		// call the PL/SQL procedure
		List<Customer>  list=query.getResultList();
		return list;
		
		}

}
