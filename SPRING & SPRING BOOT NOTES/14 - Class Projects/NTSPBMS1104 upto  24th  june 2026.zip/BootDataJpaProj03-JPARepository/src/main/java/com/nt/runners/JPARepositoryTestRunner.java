package com.nt.runners;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import com.nt.entity.Customer;
import com.nt.service.ICustomerMgmtService;

@Component
public class JPARepositoryTestRunner implements CommandLineRunner {
	@Autowired
	private   ICustomerMgmtService  custService;

	@Override
	public void run(String... args) throws Exception {
		/*try {
			String msg=custService.removeCustomersByIdsInBatch(List.of(1012,1045,3456,5778));
			System.out.println(msg);
		}
		catch(Exception e) {
			e.printStackTrace();
		}*/
		
		/*	try {
				Customer cust=new Customer();
				cust.setCaddrs("hyd"); cust.setCname("raja");
				//invoke the method
				List<Customer> list=custService.showAllCustomersByExampleData(cust, true, "caddrs");
				list.forEach(System.out::println);
			}
			catch(Exception e) {
				e.printStackTrace();
			}*/
		
		/*try {
			Customer customer=custService.showCustomerById(2345);
			//System.out.println(customer);
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		*/
		
		try {
			Customer cust=custService.fetchCustomerById(12345);
			System.out.println("proxy obj class name::"+cust.getClass()+"...."+cust.getClass().getSuperclass());
			//System.out.println("Customer obj data ::"+cust.getCno());
			//System.out.println("--------------------");
			System.out.println("customer bill amount ::"+cust.getBillAmt());
			System.out.println("------------------------");
			System.out.println("customer addrs ::"+cust.getCaddrs());
			
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}

}
