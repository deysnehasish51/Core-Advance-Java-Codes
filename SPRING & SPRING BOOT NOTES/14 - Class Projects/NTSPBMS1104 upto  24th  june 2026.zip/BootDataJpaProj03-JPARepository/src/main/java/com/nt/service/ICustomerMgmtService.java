package com.nt.service;

import java.util.List;

import com.nt.entity.Customer;

public interface ICustomerMgmtService {
    public String   removeCustomersByIdsInBatch(Iterable<Integer> ids);
    public  List<Customer>  showAllCustomersByExampleData(Customer customer,boolean ascOrder , String ...props);
    public  Customer  showCustomerById(int id);
    public  Customer  fetchCustomerById(int id);
    
}
