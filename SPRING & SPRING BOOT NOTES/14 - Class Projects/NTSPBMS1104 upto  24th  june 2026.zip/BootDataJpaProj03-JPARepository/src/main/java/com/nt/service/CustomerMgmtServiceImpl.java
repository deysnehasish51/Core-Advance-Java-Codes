package com.nt.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Example;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.nt.entity.Customer;
import com.nt.repository.ICustomerRepository;

@Service
public class CustomerMgmtServiceImpl implements ICustomerMgmtService {
	@Autowired
	private ICustomerRepository  custRepo;

	@Override
	public String removeCustomersByIdsInBatch(Iterable<Integer> ids) {
		//Load objects
		List<Customer> list=custRepo.findAllById(ids);
		if(list.size()!=0) {
			custRepo.deleteAllByIdInBatch(ids);
			return   list.size()+"  records are deleted";
		}
		return "records are not found for deletion";
	}

	@Override
	public List<Customer> showAllCustomersByExampleData(Customer customer,boolean ascOrder, String ...props) {
		  //create Example object
		 Example<Customer> example=Example.of(customer);
		 //create Sort object
		 Sort sort=Sort.by(ascOrder?Sort.Direction.ASC:Sort.Direction.DESC, props);
		 //execute  the Query
		 List<Customer>  list=custRepo.findAll(example, sort);
		return list;
	}
	
	@Override
	public Customer showCustomerById(int id) {
		//Load the object
		Customer customer=custRepo.findById(id).orElseThrow(()->new IllegalArgumentException("Invalid Id"));
		return customer;
	}
	
	@Override
	public Customer fetchCustomerById(int id) {
		//Load object
		Customer  proxy=custRepo.getReferenceById(id);
		return proxy;
	}

}
