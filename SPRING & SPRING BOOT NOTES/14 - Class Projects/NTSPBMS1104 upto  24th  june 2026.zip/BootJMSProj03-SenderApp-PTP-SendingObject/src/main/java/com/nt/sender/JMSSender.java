package com.nt.sender;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.stereotype.Component;

import com.nt.model.Student;

@Component
public class JMSSender  implements  CommandLineRunner {
	@Autowired
   private  JmsTemplate  template;
	
	@Override
	public void run(String... args) throws Exception {
		 //prepare object with  data
		Student  st1=new Student(1001, "rajesh","hyd", 89.9f);
	   template.convertAndSend("mq2", st1);	
	   System.out.println("Object Message  is sent");
	}
	
	
}
