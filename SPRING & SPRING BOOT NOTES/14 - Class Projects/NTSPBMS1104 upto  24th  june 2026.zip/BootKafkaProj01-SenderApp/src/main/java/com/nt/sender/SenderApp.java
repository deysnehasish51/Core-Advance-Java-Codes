
package com.nt.sender;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Component;

@Component
public class SenderApp implements  CommandLineRunner {
	@Autowired
   private KafkaTemplate<String, String>  template;
	
	@Override
	public void run(String... args) throws Exception {
		template.send("tpc1", "Date time is ::"+new Date());
		System.out.println("Message Sent");
		
		
	}
	
	
}
