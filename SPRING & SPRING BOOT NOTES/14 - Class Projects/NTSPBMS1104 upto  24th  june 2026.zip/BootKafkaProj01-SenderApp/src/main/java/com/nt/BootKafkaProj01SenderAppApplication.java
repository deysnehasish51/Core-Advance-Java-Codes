package com.nt;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BootKafkaProj01SenderAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(BootKafkaProj01SenderAppApplication.class, args);
	}

}
