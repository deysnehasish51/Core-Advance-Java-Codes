package com.nt.sender;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

@Component
public class JMSSender   {
	@Autowired
   private  JmsTemplate  template;
	
	//@Scheduled(cron="0/30  * * * * * ")
	@Scheduled(cron="${cron.expr}")
	public void send()  {
	   template.send("mq1", ses-> ses.createTextMessage(" Report on "+new Date()));	
	   System.out.println("Message  is sent");
	}
	
	
}
