package com.nt.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.nt.entity.Student;

public interface IStudentRepository extends JpaRepository<Student, Integer> {
	
	//@Query(value="SELECT (SYSDATE-DOB)/365.25  FROM JPA_JODA_STUDENT WHERE SNO=:no ",nativeQuery = true) //oracle
	@Query(value="SELECT TIMESTAMPDIFF(DAY, dob, CURDATE())/365.25  FROM JPA_JODA_STUDENT WHERE SNO=:no ",nativeQuery = true) //mysql
	
	public    double   showStudentAgeSno(int no);

}
