package com.nt.service;

import com.nt.entity.Student;

public interface IStudentMgmtService {
    public  String  registerStudent(Student  st);
    public  Iterable<Student>  showAllStudents();
    public   double  findStudentAgeBySno(int sno);
   
}
