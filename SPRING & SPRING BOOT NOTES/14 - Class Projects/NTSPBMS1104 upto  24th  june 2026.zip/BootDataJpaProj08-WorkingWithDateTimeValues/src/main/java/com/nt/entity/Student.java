package com.nt.entity;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@RequiredArgsConstructor
@Table(name="JPA_JODA_STUDENT")
public class Student {
	@Id
	@SequenceGenerator(name="gen1",sequenceName = "SNO_SEQ",initialValue = 100 ,allocationSize = 1)
	@GeneratedValue(generator="gen1",strategy =GenerationType.SEQUENCE )
	private  Integer sno;
	@NonNull
	@Column(length = 30)
	private  String  sname;
	@NonNull
	private  LocalDate  dob;
	@NonNull
	private  LocalTime tob;
	@NonNull
	private  LocalDateTime doj;
	@NonNull
	private  Boolean single;

}
