package com.nt.runners;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import com.nt.entity.Student;
import com.nt.service.IStudentMgmtService;

@Component
public class JODADateTimeTestRunner implements CommandLineRunner {
	@Autowired
	private  IStudentMgmtService  studService;

	@Override
	public void run(String... args) throws Exception {
		/*try {
		   Student st=new Student("Raja",LocalDate.of(1990, 10, 20),
				                                                      LocalTime.of(20, 10, 20),
				                                                      LocalDateTime.of(2015, 10, 21, 10, 20),
				                                                      true);
		   String msg=studService.registerStudent(st);
		   System.out.println(msg);
		}
		catch(Exception e) {
		   e.printStackTrace();
		}*/
		
		/*	try {
				 studService.showAllStudents().forEach(System.out::println);
				 System.out.println("-------------------------");
				 studService.showAllStudents().forEach(st->{
					 System.out.println(st.getSno()+" "+st.getSname()+"  "+st.getSingle()+" "+st.getTob());
					 LocalDate  dob=st.getDob();
					 LocalDateTime doj=st.getDoj();
					 //convert  dob to  dd-MM-yy format
					  DateTimeFormatter formatter=DateTimeFormatter.ofPattern("dd-MM-yy");
					  String  formatedDOB=dob.format(formatter);
					  System.out.println(formatedDOB);
					//convert  doj to  dd-MM-yy HH:mm:ss format
					  DateTimeFormatter formatter1=DateTimeFormatter.ofPattern("dd-MM-yy HH:mm:ss");
					  String  formatedDOJ=doj.format(formatter1);
					  System.out.println(formatedDOJ);
				 });
			}
			catch(Exception e) {
				e.printStackTrace();
			}*/
		
		try {
			double age=studService.findStudentAgeBySno(100);
			System.out.println(age);
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}

}
