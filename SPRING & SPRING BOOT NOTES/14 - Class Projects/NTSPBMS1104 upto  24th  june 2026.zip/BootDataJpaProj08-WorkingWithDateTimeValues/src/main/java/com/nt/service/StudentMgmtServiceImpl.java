package com.nt.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nt.entity.Student;
import com.nt.repository.IStudentRepository;

@Service
public class StudentMgmtServiceImpl implements IStudentMgmtService {
	@Autowired
	private  IStudentRepository studRepo;

	@Override
	public String registerStudent(Student st) {
		//save object
		int idVal=studRepo.save(st).getSno();
		return  "Student is registered having id Value ::"+idVal;
	}

	@Override
	public Iterable<Student> showAllStudents() {
		//use repo
		return studRepo.findAll();
	}
	
	@Override
	public double findStudentAgeBySno(int sno) {
		return studRepo.showStudentAgeSno(sno);
	}


}
