package com.nt;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BootDataJpaProj08WorkingWithDateTimeValuesApplication {

	public static void main(String[] args) {
		SpringApplication.run(BootDataJpaProj08WorkingWithDateTimeValuesApplication.class, args);
	}

}
