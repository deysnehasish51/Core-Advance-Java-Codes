package com.nt.runners;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import com.nt.entity.Customer;
import com.nt.service.ICustomerMgmtService;

@Component
public class CrudRepositoryTestRunner implements CommandLineRunner {
	@Autowired
	private ICustomerMgmtService  custService;

	@Override
	public void run(String... args) throws Exception {
		/*try {
			Customer  cust=new Customer();
			//cust.setCno(3556);
			cust.setCname("suresh");
			cust.setCaddrs("hyd"); cust.setBillAmt(3900.0);
			
			//invoke the method
			String  msg=custService.registerCustomer(cust);
			System.out.println(msg);
			
			Thread.sleep(30000);
		}//try
		catch(Exception e) {
			e.printStackTrace();
		}*/
		
		/*	try {
				Customer  cust1=new Customer("rajesh","hyd",4555.0);
				Customer  cust2=new Customer("suresh","delhi",5565.0);
				Customer  cust3=new Customer("mahesh","mubai",5565.0);
				List<Customer>  list=List.of(cust1,cust2,cust3);
				String  msg1=custService.regsiterBatchCustomers(list);
				System.out.println(msg1);
			}
			catch(Exception e) {
				e.printStackTrace();
			}*/
		
		/*try {
			long count=custService.showCustomerCount();
			System.out.println("Customer count ::"+count);
		}
		catch(Exception e) {
			e.printStackTrace();
		}*/
		
		/*try {
			boolean flag=custService.checkCustomerAvailability(2014);
			System.out.println(flag?"Customer is avaiable":"Customer is not avaiable");
		}
		catch(Exception e) {
			e.printStackTrace();
		}*/
		
		/*try {
			Iterable<Customer>  list=custService.showAllCustomers();
			list.forEach(cust->{
				System.out.println(cust);
			});
			System.out.println("------------------------");
			list.forEach(cust->System.out.println(cust));
			System.out.println("------------------------");
			list.forEach(System.out::println);
			System.out.println("------------------------");
			StreamSupport.stream(list.spliterator(), false).forEach(System.out::println);
			System.out.println("-----------------------");
			Iterable<Customer>  list1=StreamSupport.stream(list.spliterator(), false)
					                                .filter(cust->!"hyd".equalsIgnoreCase(cust.getCaddrs())).collect(Collectors.toList());
			list1.forEach(System.out::println);
			System.out.println("-----------------");
			list.forEach(System.out::println);
			
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		*/
		
		/*try {
			Iterable<Customer>  it=custService.showCustomersByIds(null);
			it.forEach(System.out::println);
		}
		catch(Exception e) {
			e.printStackTrace();
		}*/
		
		/*try {
			Optional<Customer>  opt=custService.showCustomerById(2103);
			if(opt.isPresent()) {
				   Customer  cust=opt.get();
				   System.out.println("Customer obj  data::"+cust);
			}
			else {
				System.out.println("Customer not found");
			}
			
		}
		catch(Exception e) {
			e.printStackTrace();
		}*/
		
		/*try {
		  String msg=custService.fetchCustomerById(2003);
		        System.out.println(msg);		
		}
		catch(Exception e) {
			e.printStackTrace();
		}*/
		
		/*	try {
				Customer cust=custService.getCustomerById(2013);
				System.out.println(cust);
			}
			catch(Exception e) {
				System.err.println("problem::"+e.getMessage());
				e.printStackTrace();
			}*/
		
		/*try {
			Customer  cust=custService.readCustomerById(2014);
			//System.out.println("Customer Dertails ::"+cust);
		}
		catch(Exception e) {
			e.printStackTrace();
		}*/
		
		/*try {
			String msg=custService.updateBillAmountByGivingDiscount(2103, 10.0);
			System.out.println(msg);
		}
		catch(Exception e) {
			e.printStackTrace();
		}*/
		
		/*try {
			Customer cust=new Customer(2035, "rajesh kumar", "hyd-32", 8200.0);
			String msg=custService.registerOrUpdateCustomer(cust);
			System.out.println(msg);
		}
		catch(Exception e) {
			e.printStackTrace();
		}*/
		
		/*try {
			String msg=custService.removeCustomerById(2003);
			System.out.println(msg);
		}
		catch(Exception e) {
			e.printStackTrace();
		}*/
		

		/*	try {
				String msg=custService.removeCustomersByIds(List.of(2003, 2004, 2005,2010,2030));
				System.out.println(msg);
			}
			catch(Exception e) {
				e.printStackTrace();
			}*/
		
		try {
			String msg=custService.removeAllCustomers();
			System.out.println(msg);
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}

}
