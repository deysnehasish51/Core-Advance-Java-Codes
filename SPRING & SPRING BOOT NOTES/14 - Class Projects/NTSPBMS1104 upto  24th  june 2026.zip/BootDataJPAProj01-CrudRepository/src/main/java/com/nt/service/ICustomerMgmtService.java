package com.nt.service;

import java.util.List;
import java.util.Optional;

import com.nt.entity.Customer;

public interface ICustomerMgmtService {
   public   String  registerCustomer(Customer  cust);
   public   String  regsiterBatchCustomers(List<Customer> list);
   public    long   showCustomerCount();
   public  boolean   checkCustomerAvailability(int id);
   public   Iterable<Customer>   showAllCustomers();
   public   Iterable<Customer>  showCustomersByIds(Iterable<Integer> ids);
   public    Optional<Customer> showCustomerById(int cno);
   public   String   fetchCustomerById(int id);
   public   Customer    getCustomerById(int id);
   public   Customer    readCustomerById(int id);
   public   String   updateBillAmountByGivingDiscount(int  id, double disCountPercentage);
   public   String    registerOrUpdateCustomer(Customer cust);
   public   String   removeCustomerById(int id);
   public   String    removeCustomersByIds(Iterable<Integer> ids);
   public   String  removeAllCustomers();
   
}
