package com.nt.service;

import java.util.List;
import java.util.Optional;
import java.util.stream.StreamSupport;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nt.entity.Customer;
import com.nt.exception.CustomerNotFoundException;
import com.nt.repository.ICustomerRepository;

@Service
public class CustomerMgmtServiceImpl implements ICustomerMgmtService {
	@Autowired
	private   ICustomerRepository custRepo;

	@Override
	public String registerCustomer(Customer cust) {
		System.out.println("CustomerMgmtServiceImpl.registerCustomer()");
	/*	System.out.println("proxy obj class name::"+custRepo.getClass());
		System.out.println("proxy obj class implemented interfaces::"+Arrays.toString(custRepo.getClass().getInterfaces()));
		System.out.println("method names in prpxy class "+Arrays.toString(custRepo.getClass().getMethods()));*/
		//save the object
		  Customer  savedCust=custRepo.save(cust);
		//get the generated id value
		  int idVal=savedCust.getCno();
		return "Customer object is saved with Id value ::"+idVal;
	}

	
	
	@Override
	public String regsiterBatchCustomers(List<Customer> list) {
		// use  repo
		Iterable<Customer>  savedCustomers=custRepo.saveAll(list);
		//use  stream api to  map id values List<Integer>  collection from Iterable<Customer> collection
		List<Integer>  ids=StreamSupport.stream(savedCustomers.spliterator(), false).map(Customer::getCno).toList();
		
	/*	//get the id values
		List<Integer> ids=new ArrayList<>();
		savedCustomers.forEach(cust->{
			ids.add(cust.getCno());
		});*/
		return ids.size()+" no.of  customers saved with id values ::"+ids;
	}
	
	@Override
	public long showCustomerCount() {
		return custRepo.count();
	}
	
	@Override
	public boolean checkCustomerAvailability(int id) {
		 //check the  customer availability
		boolean  flag=custRepo.existsById(id);
		return flag;
	}
	
	@Override
	public Iterable<Customer> showAllCustomers() {
		Iterable<Customer> it=custRepo.findAll();
		Iterable<Customer> it1=StreamSupport.stream(it.spliterator(), false)
		                                          .sorted((cust1,cust2)->cust1.getBillAmt().compareTo(cust2.getBillAmt()))
		                                          .toList();
		                                          
		return it1;
	}
	
	@Override
	public Iterable<Customer> showCustomersByIds(Iterable<Integer> ids) {
		//Load the customers
		Iterable<Customer>  it=custRepo.findAllById(ids);
		return it;
	}



	@Override
	public Optional<Customer> showCustomerById(int cno) {
		//use repo
		Optional<Customer>  opt=custRepo.findById(cno);
		return opt;
		}
	
	@Override
	public String fetchCustomerById(int id) {
		Optional<Customer>  opt=custRepo.findById(id);
		if(opt.isPresent()) {
			Customer cust=opt.get();
			return  "Customer Details are :"+cust;
		}
		return "Customer is  not found";
	}
	
	@Override
	public Customer getCustomerById(int id) {
		/*		Optional<Customer>  opt=custRepo.findById(id);
				if(opt.isPresent()) {
					Customer cust=opt.get();
					return cust;
				}
				else {
					 //throw  new IllegalArgumentException("Invalid Id");
					throw  new CustomerNotFoundException("Invalid Id");
				}
		*/
		 //return custRepo.findById(id).orElseThrow(()->new IllegalArgumentException("Invalid Id"));
	return custRepo.findById(id).orElseThrow(()->new CustomerNotFoundException("Invalid Id")); 
	}
	
	@Override
	public Customer readCustomerById(int id) {
		Customer dummy=new Customer(7, "rajesh", "hyd",9000.0);
		Customer cust=custRepo.findById(id).orElse(dummy);
		return cust;
	}
	
	@Override
	public String updateBillAmountByGivingDiscount(int id, double disCountPercentage) {
		//Load the object
		Customer  cust=custRepo.findById(id).orElseThrow(()->new CustomerNotFoundException("Invalid Id"));
		//update the billamount
		cust.setBillAmt(cust.getBillAmt()-(cust.getBillAmt()*disCountPercentage/100.0));
		//save the object
		custRepo.save(cust);
		
		return "Customer Bill amount is updated with discount";
		
	}
	@Override
	public String registerOrUpdateCustomer(Customer cust) {
		//Load  the object
		Optional<Customer>  opt=custRepo.findById(cust.getCno());
		if(opt.isPresent()) {
			//update the object
			custRepo.save(cust);
			return cust.getCno()+"  Full Customer details are updated"; 
		}
		else {
			  //save the object
		        custRepo.save(cust);
		        return  cust.getCno()+" Customer Details are registered";
		}
	
	}

	@Override
	public String removeCustomerById(int id) {
           //Load object
		Optional<Customer> opt=custRepo.findById(id);
		if(opt.isEmpty()) {
			return  id+" customer is not found for deletion ";
		}
		else {
			custRepo.deleteById(id);
			return  id+" customer is  found and deleted ";
		}
	}



	@Override
	public String removeCustomersByIds(Iterable<Integer> ids) {
		//Load objects  by Ids
		long count=StreamSupport.stream(custRepo.findAllById(ids).spliterator(),false).count();
		if(count==0)
			return  ids+" are not found for deletion";
		else {
			custRepo.deleteAllById(ids);
			return  count+" no.of ids are found for deletion";
		}
	}
	
	@Override
	public String removeAllCustomers() {
		long count=custRepo.count();
		if(count!=0) {
			custRepo.deleteAll();
			return count+"no.of records are deleted";
		}
		return " records not found for deletion";
	}
	
	

}
