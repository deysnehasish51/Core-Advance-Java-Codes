package com.nt.core;

import java.time.LocalDate;
import java.util.Optional;

public class OptionalAPITest {
	
	public  LocalDate   createDate(int year,int month ,int day) {
		 if(year<1900  || month<=0  || day<=0)
			   return null;
		 else
			 return  LocalDate.of(year, month,day);
	}
	
	public Optional<LocalDate>   createDate1(int year,int month ,int day) {
		 if(year<1900  || month<=0  || day<=0)
			   return Optional.empty();
		 else
			 return  Optional.of(LocalDate.of(year, month,day));
	}
	
	
	public static void main(String[] args) {
		/*	  OptionalAPITest test=new OptionalAPITest();
			    LocalDate date=test.createDate(2000, 10, 20);
			    System.out.println(date.toString());
			    System.out.println("---------------------------");
			    LocalDate date1=test.createDate(2000, -10, 20);
			    System.out.println(date1.toString());
		*/	    
		
		  OptionalAPITest test1=new OptionalAPITest();
		  Optional<LocalDate>  opt=test1.createDate1(1999, 10, -20);
		  if(opt.isEmpty())
			  System.out.println("wrong date values are given");
		  else {
			  LocalDate  ldt=opt.get();
			  System.out.println("date is ::"+ldt);
		  }
			  
		    
	}

}
