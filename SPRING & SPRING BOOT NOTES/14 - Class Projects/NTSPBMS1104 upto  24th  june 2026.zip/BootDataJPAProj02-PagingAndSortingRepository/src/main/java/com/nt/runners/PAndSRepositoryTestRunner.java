package com.nt.runners;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Component;

import com.nt.entity.Customer;
import com.nt.service.ICustomerMgmtService;

@Component
public class PAndSRepositoryTestRunner implements CommandLineRunner {
	@Autowired
	private  ICustomerMgmtService custService;

	@Override
	public void run(String... args) throws Exception {
		/*try {
			Iterable<Customer>  list=custService.showCustomersAsSorted(false, "caddrs","cname");
			list.forEach(System.out::println);
		}
		catch(Exception e) {
			e.printStackTrace();
		}*/
		
		/*	try {
				Page<Customer>  page=custService.showCustomersByPageNo(0, 3);
				List<Customer> list=page.getContent();
				System.out.println("--- records are ----- of  "+(page.getNumber()+1)+"/"+page.getTotalPages());
				list.forEach(System.out::println);
				System.out.println("-------------------------");
				System.out.println(" no.of records in current page ::"+page.getNumberOfElements());
				System.out.println(" It is  first page ?::"+page.isFirst());
				System.out.println("It is  last page? ::"+page.isLast());
				System.out.println(" is  current  page having next page?"+page.hasNext());
				System.out.println(" is  current  page having previous page?"+page.hasPrevious());
				
			}
			catch(Exception e) {
			   e.printStackTrace();	
			}
		*/
		
		/*	try {
				Page<Customer> page=custService.showSortedCustomersByPageNo(1, 4, true, "caddrs","billAmt");
				System.out.println(" records of  "+(page.getNumber()+1)+" /"+page.getTotalPages());
				page.forEach(System.out::println);
			}
			catch(Exception e) {
				e.printStackTrace();
			}*/
		
		  try {
			  custService.showCustomersByPagination(4);
		  }
		  catch(Exception e) {
			  e.printStackTrace();
		  }
	}

}
