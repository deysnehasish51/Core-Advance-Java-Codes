package com.nt.service;

import org.springframework.data.domain.Page;

import com.nt.entity.Customer;

public interface ICustomerMgmtService {
    public  Iterable<Customer>  showCustomersAsSorted(boolean ascOrder, String ... props);
    public    Page<Customer>  showCustomersByPageNo(int  pageNo,int pageSize);
    public    Page<Customer>  showSortedCustomersByPageNo(int  pageNo,int pageSize,boolean ascOrder, String ...props);
    public  void   showCustomersByPagination(int pageSize);
    
    
}
