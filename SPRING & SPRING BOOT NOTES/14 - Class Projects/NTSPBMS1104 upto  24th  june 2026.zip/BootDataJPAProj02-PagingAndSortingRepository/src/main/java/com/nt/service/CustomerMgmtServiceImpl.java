package com.nt.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.nt.entity.Customer;
import com.nt.repository.ICustomerRepository;

@Service
public class CustomerMgmtServiceImpl implements ICustomerMgmtService {
	@Autowired
	private  ICustomerRepository  custRepo;

	@Override
	public Iterable<Customer> showCustomersAsSorted(boolean ascOrder, String... props) {
		//create  Sort object
		Sort sort=Sort.by(ascOrder?Sort.Direction.ASC:Sort.Direction.DESC, props);
		//invoke the method
		Iterable<Customer>  list=custRepo.findAll(sort);
		return list;
	}

	@Override
	public Page<Customer> showCustomersByPageNo(int pageNo, int pageSize) {
		//  create Pageable object
		Pageable pageable=PageRequest.of(pageNo, pageSize);
		//invoke the method
		Page<Customer> page=custRepo.findAll(pageable);
		return page;
	}
	
	@Override
	public Page<Customer> showSortedCustomersByPageNo(int pageNo, int pageSize, boolean ascOrder, String... props) {
		//create Sort object
		Sort sort=Sort.by(ascOrder?Sort.Direction.ASC: Sort.Direction.DESC, props);
		//create Pageable object
		Pageable  pageable=PageRequest.of(pageNo, pageSize,sort);
		//invoke the method
		Page<Customer>  page=custRepo.findAll(pageable);
		return page;
	}
	
	@Override
	public void showCustomersByPagination(int pageSize) {
	   // get total  records count
		long count=custRepo.count();
		
		//get  pages count
		long pagesCount=count/pageSize;
		if(count%pageSize!=0) 
			pagesCount++;
		
		//display  records page by page 
		for(int i=0;i<pagesCount;++i) {
			//create Pageable object
			Pageable  pageable=PageRequest.of(i, pageSize);
			//invoke the method
			Page<Customer> page=custRepo.findAll(pageable);
			System.out.println("----The records of  "+(page.getNumber()+1)+" /"+page.getTotalPages()+"-----------");
			page.forEach(System.out::println);
		}//for
			
		
	}//method

}//class
