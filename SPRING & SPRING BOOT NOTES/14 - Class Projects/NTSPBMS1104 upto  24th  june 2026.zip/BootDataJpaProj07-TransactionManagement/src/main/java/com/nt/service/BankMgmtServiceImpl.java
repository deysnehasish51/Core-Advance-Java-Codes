package com.nt.service;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.nt.entity.BankAccount;
import com.nt.repository.IBankRepository;

@Service
public class BankMgmtServiceImpl implements IBankMgmtService {
	@Autowired
	private  IBankRepository  bankRepo;

	@Override
	public String openBankAccount(BankAccount account) {
		account.setCreatedBy(System.getProperty("user.name"));
		//use repo
		long acno=bankRepo.save(account).getAcno();
		return "Bank Account is opened with account number::"+acno;
	}
	
	@Override
	public BankAccount showBankAccountDetailsByAcno(long acno) {
		//Load the object
		return  bankRepo.findById(acno).orElseThrow(()->new IllegalArgumentException("Invalid Id"));
	}
	
	@Override
	public String withdrawAmount(long acno, double amt) {
		//Load object
		BankAccount account=bankRepo.findById(acno).orElseThrow(()->new IllegalArgumentException("Invalid Id"));
	     //withdraw amount 
		account.setBalance(account.getBalance()-amt);
		account.setUpdatedBy(System.getProperty("user.name"));
	     //update the object
		bankRepo.save(account);
		return  amt+" amount is withdrawn from  the account number::"+acno;
	}
	
	@Override
	public String updateAccountDetails(BankAccount newDetails) {
		//Load  object  that gives  old data and metadata properties
		BankAccount account=bankRepo.findById(newDetails.getAcno()).orElseThrow(()->new IllegalArgumentException("Invalid Id"));
	   //copy new object  data property values to   loaded object
		BeanUtils.copyProperties(newDetails,account,"updateCount");
		System.out.println(newDetails);
	
		//update the object
		bankRepo.save(account);
		return account.getAcno()+" Account details are updated";
	}
	
	@Override
	public String depositeAmount(long acno, double amt) {
		//Load object
		BankAccount account=bankRepo.findById(acno).orElseThrow(()->new IllegalArgumentException("Invalid Id"));
	     //withdraw amount 
		account.setBalance(account.getBalance()+amt);
		account.setUpdatedBy(System.getProperty("user.name"));
	     //update the object
		bankRepo.save(account);
		return  amt+" amount is deposited to  the account number::"+acno;
	}
	
	@Override
	//@Transactional(propagation = Propagation.REQUIRED)
	//@Transactional(propagation = Propagation.REQUIRES_NEW)
	//@Transactional(propagation = Propagation.SUPPORTS)
	//@Transactional(propagation = Propagation.NOT_SUPPORTED)
	//@Transactional(propagation = Propagation.MANDATORY)
	//@Transactional(propagation = Propagation.NEVER)
	@Transactional(propagation = Propagation.NESTED)
	public String transferMoney(long srcAcno, long destAcno, double amt) {
		withdrawAmount(srcAcno, amt);
		depositeAmount(destAcno, amt);
		return amt+"amount is transfered from "+srcAcno+" to  "+destAcno;
				
	}
	

}
