package com.nt.service;

import com.nt.entity.BankAccount;

public interface IBankMgmtService {
    public  String  openBankAccount(BankAccount account);
    public  BankAccount   showBankAccountDetailsByAcno(long acno);
    public  String  withdrawAmount(long acno,double  amt);
    public  String  depositeAmount(long acno,double  amt);
    public  String   transferMoney(long  srcAcno,long destAcno,double amt)throws IllegalArgumentException;
    public  String  updateAccountDetails(BankAccount newDetails);
}
