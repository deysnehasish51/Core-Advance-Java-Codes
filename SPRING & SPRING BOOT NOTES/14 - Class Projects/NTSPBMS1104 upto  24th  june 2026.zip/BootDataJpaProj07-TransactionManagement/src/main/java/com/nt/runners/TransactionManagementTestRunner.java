package com.nt.runners;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import com.nt.entity.BankAccount;
import com.nt.service.IBankMgmtService;

@Component
public class TransactionManagementTestRunner implements CommandLineRunner {
	@Autowired
	private  IBankMgmtService  bankService;

	@Override
	public void run(String... args) throws Exception {
	
		 try {
			 String msg=bankService.transferMoney(10000003, 10000007, 1000.0);
			 System.out.println(msg);
		 }
		 catch(Exception e) {
			 System.err.println("Problem in Money Transfering");
			 e.printStackTrace();
		 }
		 
		
	}

}
