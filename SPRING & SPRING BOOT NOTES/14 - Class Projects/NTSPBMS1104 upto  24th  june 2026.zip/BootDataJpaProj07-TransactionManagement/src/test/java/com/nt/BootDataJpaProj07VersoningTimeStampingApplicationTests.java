package com.nt;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BootDataJpaProj07VersoningTimeStampingApplicationTests {

	@Test
	void contextLoads() {
	}

}
