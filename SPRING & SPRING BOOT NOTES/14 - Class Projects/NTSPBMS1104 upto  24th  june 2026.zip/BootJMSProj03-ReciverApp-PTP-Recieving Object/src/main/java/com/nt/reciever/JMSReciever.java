package com.nt.reciever;

import org.springframework.jms.annotation.JmsListener;
import org.springframework.stereotype.Component;

import com.nt.model.Student;

@Component
public class JMSReciever {

	@JmsListener(destination = "mq2")
	public  void   readMessage(Student st) {
		System.out.println("The Object message is ::"+st);
	}
}
