package com.nt;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BootJmsProj03ReciverAppPtpApplicationTests {

	@Test
	void contextLoads() {
	}

}
