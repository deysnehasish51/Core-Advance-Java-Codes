package com.nt;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BootDataJpaProj12CallingPlSqlProcedureOracleApplication {

	public static void main(String[] args) {
		SpringApplication.run(BootDataJpaProj12CallingPlSqlProcedureOracleApplication.class, args);
	}

}
