package com.nt.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nt.entity.Customer;

import jakarta.persistence.EntityManager;
import jakarta.persistence.ParameterMode;
import jakarta.persistence.StoredProcedureQuery;


@Service
public class CustomerMgmtServiceImpl implements ICustomerMgmtService {
	   @Autowired
       private  EntityManager  manager;
	   
		/*  CREATE DEFINER=`root`@`localhost` PROCEDURE `p_authentication`(in uname varchar(45) , in pwd varchar(45),out result  varchar(10))
			   BEGIN
			     declare cnt int(1);
			     
			     select count(*) into cnt from  user_details where  username=uname and password=pwd;
			     if(cnt<>0) then
			        set result='Valid Credentials';
			     else
			         set result='Invalid Credetials';
			     end  if;
			    END
		*/	   

	   @Override
	   public String authenticate(String user, String pwd) {
		   //create StoredProcedureQuery object
		   StoredProcedureQuery  query=manager.createStoredProcedureQuery("p_authentication");
		   //register the params
		   query.registerStoredProcedureParameter(1, String.class, ParameterMode.IN);
		   query.registerStoredProcedureParameter(2, String.class, ParameterMode.IN);
		   query.registerStoredProcedureParameter(3, String.class, ParameterMode.OUT);
		   
		   //set values to IN params
		   query.setParameter(1, user);
		   query.setParameter(2, pwd);
		   //call the PL/SQL procedure
		   String result=(String)query.getOutputParameterValue(3);
		   return result;
	   }
	   
	
		
}
