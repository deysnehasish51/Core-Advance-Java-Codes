package com.nt.service;

import java.util.List;

import com.nt.entity.Customer;

public interface ICustomerMgmtService {
    public  String    authenticate(String user,String pwd);
}
