package com.nt.runners;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import com.nt.entity.Customer;
import com.nt.service.ICustomerMgmtService;

@Component
public class PL_SQLProcuereCallTestRunner implements CommandLineRunner {
	@Autowired
	private  ICustomerMgmtService  custService;

	@Override
	public void run(String... args) throws Exception {
		try {
			String msg=custService.authenticate("raja", "rani1");
			System.out.println(msg);
		}
		catch(Exception e) {
			e.printStackTrace();
		}

	}

}
