package com.nt.runners;

import java.time.LocalDateTime;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import com.nt.repository.ICustomerRepository;

@Component
public class JPARepositoryTestRunner implements CommandLineRunner {

    @Autowired
	private  ICustomerRepository custRepo;

    
	@Override
	public void run(String... args) throws Exception {
	
		/*	try {
				List<Customer>  list=custRepo.showCustomersByBillAmt(1000.0, 4000.0);
				list.forEach(System.out::println);
			}
			catch(Exception e) {
				e.printStackTrace();
			}*/
		/*	try {
				List<Customer>  list=custRepo.showCustomersByAddrs("hyd", "vizag", "delhi");
				list.forEach(System.out::println);
				System.out.println("-------------------------");
				List<Object[]>  list1=custRepo.showCustomersDataByAddrs("hyd", "vizag", "delhi");
				list1.forEach(row->System.out.println(Arrays.toString(row)));
				System.out.println("-------------------------");
				List<String>  list2=custRepo.showCustomerNamesByAddrs("hyd", "vizag", "delhi");
				list2.forEach(System.out::println);
				
			}
			catch(Exception e) {
				e.printStackTrace();
			}
		*/
		
		/*	try {
				Optional<Customer>  opt=custRepo.showCustomerByName("karan");
				System.out.println(opt.isEmpty()?"Customer not found ":"customer details ::"+opt.get());
				System.out.println("-------------------------------");
				Optional<Object>  opt1=custRepo.showCustomerDataByName("karan");
				System.out.println(opt1.isEmpty()?"Customer not found ":"customer details ::"+Arrays.toString((Object[])opt1.get()));
				System.out.println("-------------------------------");
				Optional<String>  opt2=custRepo.showCustomerAddrsByName("karan");
				System.out.println(opt2.isEmpty()?"Customer not found ":"customer address is ::"+opt2.get());
			}
			catch(Exception e) {
				e.printStackTrace();
			}*/
		
		/*		try {
					long uniqueCount=custRepo.showUniqueAddressCount();
					System.out.println("unique customers count ::"+uniqueCount);
					System.out.println("-------------------------------------");
					Optional<Object> opt=custRepo.showAggregateCustomerData();
					if(opt.isPresent()) {
						Object[] row=(Object[])opt.get();
						System.out.println("aggregate results are ::"+row[0]+"..."+row[1]+"...."+row[2]+"..."+row[3]+"...."+row[4]);
					}
					else {
						System.out.println("records not found");
					}
				}
				catch(Exception e) {
					e.printStackTrace();
				}
		*/
		
		/*try {
			int count=custRepo.hikeBillAmtByCity("hyd", 10.0);
			System.out.println("no.of records that are effected ::"+count);
		}
		catch(Exception e) {
			e.printStackTrace();
		}*/
		
		
		/*	try {
				long count=custRepo.deleteCustomerByAddresses("hyd", "pune", "delhi");
				System.out.println("no.of  customers that are deleted::"+count);
			}
			catch(Exception e) {
				e.printStackTrace();
				
			}
		
			*/
		
		try {
			LocalDateTime  time=custRepo.generateSystemDateTime();
			System.out.println("System Date and Time vlaues ::"+time);
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		
	}
}
