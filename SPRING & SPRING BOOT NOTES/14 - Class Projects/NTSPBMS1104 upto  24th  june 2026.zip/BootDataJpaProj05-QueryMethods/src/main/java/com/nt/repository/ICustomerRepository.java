package com.nt.repository;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;

import com.nt.entity.Customer;

@Transactional
public interface ICustomerRepository extends JpaRepository<Customer, Integer> {
          //@Query("from Customer  where billAmt>=?1 and billAmt<=?2")
	
	@Query("from Customer  where billAmt>=?1 and billAmt<=?2 ")
	public   List<Customer> showCustomersByBillAmt(double min,double max);
	
     //public   List<Customer> showCustomersByBillAmt(@Param("min")double start,@Param("max") double end);
	
	// Bulk operations ----- Entity  query
	@Query("from Customer where  caddrs in(:city1,:city2,:city3)  order by  caddrs")
	public  List<Customer>  showCustomersByAddrs(String city1,String city2,String city3);
	
	// Bulk operations ----- Scalar Query --selecting specific multiple col values
	@Query("select cno,cname,caddrs from Customer where  caddrs in(:city1,:city2,:city3)  order by  caddrs")
	public  List<Object[]>  showCustomersDataByAddrs(String city1,String city2,String city3);
	
	// Bulk operations ----- Scalar Query --selecting specific single col  values
	@Query("select  cname from Customer where  caddrs in(:city1,:city2,:city3) order by caddrs")
	public  List<String>  showCustomerNamesByAddrs(String city1,String city2,String city3);
	
	//Single row operation ----> entity  query
	@Query("from Customer   where cname=:name")
	public  Optional<Customer>   showCustomerByName(String name);
	
	//Single row operation ----> scalar  query giving specific multiple col values
		@Query("select cno,cname,caddrs from Customer   where cname=:name")
	public  Optional<Object>   showCustomerDataByName(String name);
	
	//Single row operation ----> scalar  query giving specific single col value
		@Query("select  caddrs from Customer   where cname=:name")
		public  Optional<String>   showCustomerAddrsByName(String name);
		
		//===== Aggragate  opeartions ==================
		
		@Query("select  count(distinct caddrs) from Customer")
		public   long  showUniqueAddressCount();
	
		@Query("select  count(*),max(billAmt), min(billAmt) ,avg(billAmt), sum(billAmt) from Customer")
		public   Optional<Object>  showAggregateCustomerData();
		
		
		@Query("update  Customer  set billAmt=billAmt+(billAmt*(:hikePercent/100.0)) where caddrs=:city")
		@Modifying
		//@Transactional
		public  int   hikeBillAmtByCity(String city, double hikePercent);
		
		@Query("delete  from Customer  where caddrs in(:city1,:city2,:city3)")
		@Modifying
		@Transactional
		public  int   deleteCustomerByAddresses(String city1,String city2,String city3);
		
		@Query(value="select now()  from dual ",nativeQuery=true)
		public   LocalDateTime   generateSystemDateTime();
}
