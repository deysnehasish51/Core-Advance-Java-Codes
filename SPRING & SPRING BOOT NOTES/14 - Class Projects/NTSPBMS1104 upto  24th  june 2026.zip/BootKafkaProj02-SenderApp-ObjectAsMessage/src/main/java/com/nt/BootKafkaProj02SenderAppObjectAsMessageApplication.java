package com.nt;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BootKafkaProj02SenderAppObjectAsMessageApplication {

	public static void main(String[] args) {
		SpringApplication.run(BootKafkaProj02SenderAppObjectAsMessageApplication.class, args);
	}

}
