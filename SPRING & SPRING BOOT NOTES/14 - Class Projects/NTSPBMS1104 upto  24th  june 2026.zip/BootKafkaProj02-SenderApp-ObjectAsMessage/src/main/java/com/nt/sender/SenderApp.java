//SenderApp.java
package com.nt.sender;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Component;

import com.nt.model.Employee;

@Component
public class SenderApp implements  CommandLineRunner {
	@Autowired
   private KafkaTemplate<String, Employee>  template;
	
	@Override
	public void run(String... args) throws Exception {
		template.send("tpc2", "emp Info",new Employee(101,"raja","hyd"));
		System.out.println("Object as Message Sent");
		
		
	}
	
	
}
