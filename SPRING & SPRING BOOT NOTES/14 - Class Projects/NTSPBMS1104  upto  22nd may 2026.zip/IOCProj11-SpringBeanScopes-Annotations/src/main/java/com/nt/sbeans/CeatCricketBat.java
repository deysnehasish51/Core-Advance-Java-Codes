//CeatCricketBat.java
package com.nt.sbeans;

import java.util.Random;

import org.springframework.stereotype.Component;

//@Component("ceat")
@Component
public final class  CeatCricketBat implements ICricketBat {

	public  CeatCricketBat() {
		System.out.println("CeatCricketBat:: 0-param constructor");
	}

	@Override
	public int scoreRuns() {
		System.out.println("CeatCricketBat.scoreRuns()");
		return  new Random().nextInt(200);
	}

}
