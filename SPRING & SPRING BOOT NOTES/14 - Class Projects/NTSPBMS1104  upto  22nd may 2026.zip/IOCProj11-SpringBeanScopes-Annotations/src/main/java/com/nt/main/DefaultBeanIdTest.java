package com.nt.main;

import java.util.Arrays;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.nt.config.AppConfig;

public class DefaultBeanIdTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		try (AnnotationConfigApplicationContext ctx =
				            new AnnotationConfigApplicationContext(AppConfig.class)) {
			   String ids[]=ctx.getBeanDefinitionNames();
			   System.out.println("Default Bean ids ::"+Arrays.toString(ids));
			
		}
		catch(Exception e) {
			e.printStackTrace();
		}

	}

}
