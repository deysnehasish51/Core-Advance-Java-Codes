//Printer.java
package com.nt.ston;

import org.springframework.stereotype.Component;

//@Component("p1")
public class Printer {
   //private static ref variable
	private  static  Printer  INSTANCE;
	
	  //private construtor
	private Printer() {
		System.out.println("Printer:: 0-param constructor");
	}
	
	// static factory method having singleton logics
	public  static   Printer  getInstance() {
		System.out.println("Printer.getInstance()");
		//singleton logic
		if(INSTANCE==null)
			INSTANCE=new Printer();
		return INSTANCE;
	}
	
	
	//  b.method
	public  void printData(String message) {
		System.out.println("Printer.printData()");
		System.out.println("message is ::"+message);
	}
	
	

}
