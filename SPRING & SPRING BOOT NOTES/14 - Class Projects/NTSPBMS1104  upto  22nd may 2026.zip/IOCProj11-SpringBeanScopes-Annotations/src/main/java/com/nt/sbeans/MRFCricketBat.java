//MRFCricketBat.java
package com.nt.sbeans;

import java.util.Random;

import org.springframework.stereotype.Component;

@Component("mrf")
public final class MRFCricketBat implements ICricketBat {

	public MRFCricketBat() {
		System.out.println("MRFCricketBat:: 0-param constructor");
	}

	@Override
	public int scoreRuns() {
		System.out.println("MRFCricketBat.scoreRuns()");
		return  new Random().nextInt(200);
	}

}
