//AppConfig.java
package com.nt.config;

import java.util.Date;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

import com.nt.ston.Printer;

@Configuration
@ComponentScan(basePackages = {"com.nt.sbeans"})
@ComponentScan(basePackages="com.nt.ston")
public class AppConfig {

	
	@Bean(name="dt1")
	public   Date createDate1() {
		System.out.println("AppConfig.createDate1()");
		return new Date();
	}
	
	@Bean(name="dt2")
	public  Date  createDate2() {
		System.out.println("AppConfig.createDate2()");
		return new Date(1990,10,20);
	}
	
	//@Bean(name="p1")
	@Bean
	public  Printer  createPrinter1() {
		return Printer.getInstance();
	}
	
	//@Bean(name="p2")
	@Bean
	public  Printer  createPrinter2() {
		return Printer.getInstance();
	}
	
}
