//SpringBeanScopesTest.java
package com.nt.main;

import java.util.Arrays;
import java.util.Date;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.nt.config.AppConfig;
import com.nt.sbeans.Cricketer;
import com.nt.ston.Printer;

public class SpringBeanScopesTest {

	public static void main(String[] args) {
		// create IOC container
		try (AnnotationConfigApplicationContext ctx = new AnnotationConfigApplicationContext(AppConfig.class)) {
			// get target spring bean class obj ref
				Cricketer cricketer1 = ctx.getBean("cktr", Cricketer.class);
				Cricketer cricketer2 = ctx.getBean("cktr", Cricketer.class);
				System.out.println(cricketer1.hashCode() + "..." + cricketer2.hashCode());
				System.out.println("cricker1==cricker2?" + (cricketer1 == cricketer2));
			
				System.out.println("=====================");
				
			/*	  Date dt1=ctx.getBean("dt1",Date.class); Date
				  dt2=ctx.getBean("dt2",Date.class);
				  System.out.println(dt1.hashCode()+"...."+dt2.hashCode());
				  System.out.println("dt1==dt2?"+(dt1==dt2));
				  
				  System.out.println(" spring beans count ::"+ctx.getBeanDefinitionCount());
				  System.out.println("Spring bean ids ::"+Arrays.toString(ctx.
				  getBeanDefinitionNames()));
				  
				  System.out.println("====================="); Printer
				  p11=ctx.getBean("p1",Printer.class); Printer
				  p12=ctx.getBean("p2",Printer.class);
				  System.out.println(p11.hashCode()+"  "+p12.hashCode());
				   
			*/			 

			/*
			 * String msg=cricketer.batting(); System.out.println(msg);
			 */
		} catch (Exception e) {
			e.printStackTrace();
		}

	}// main

}// class
