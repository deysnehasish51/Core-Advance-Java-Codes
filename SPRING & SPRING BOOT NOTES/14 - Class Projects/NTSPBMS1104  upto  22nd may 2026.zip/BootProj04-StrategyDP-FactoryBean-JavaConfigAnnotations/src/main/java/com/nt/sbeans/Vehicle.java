//Vehicle.java
package com.nt.sbeans;

import org.springframework.beans.factory.annotation.Qualifier;

import jakarta.annotation.Resource;
import jakarta.inject.Inject;
import jakarta.inject.Named;

@Named("vehicle")
public final class Vehicle {
	//@Inject
	//@Named("enggFactory")
	@Resource(name="enggFactory")
	private IEngine engg;
	
	public   void  Jounery (String startPlace ,String endPlace) {
		System.out.println("jounery started at ::"+startPlace);
		engg.startEngine();
		System.out.println("Journery is going  on .....from "+startPlace+"...."+endPlace);
		engg.stopEngine();
		System.out.println("Jounery  stopped at ::"+endPlace);
	}

}
