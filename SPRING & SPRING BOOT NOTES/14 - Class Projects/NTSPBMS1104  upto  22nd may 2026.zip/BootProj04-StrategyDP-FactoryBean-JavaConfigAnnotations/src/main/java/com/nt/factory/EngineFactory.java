package com.nt.factory;

import org.jspecify.annotations.Nullable;
import org.springframework.beans.factory.FactoryBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;

import com.nt.sbeans.DieselEngine;
import com.nt.sbeans.IEngine;
import com.nt.sbeans.PetrolEngine;

import jakarta.inject.Named;

@Named("enggFactory")
public class EngineFactory implements FactoryBean<IEngine> {
	@Value("${engg.id}")
	private  String enggId;
	
	@Autowired
	private  PetrolEngine  pEngine;
	@Autowired
	private DieselEngine  dEngine;

	@Override
	public IEngine getObject() throws Exception {
		 switch (enggId) {
		       case "pEngg":
		    	    return  pEngine;
		       case "dEngg":
		    	    return  dEngine;
		default:
			throw new IllegalArgumentException("Invalid  Enige id: " + enggId);
		}
	
	}

	@Override
	public @Nullable Class<IEngine> getObjectType() {
		return IEngine.class;
	}
	
	@Override
	public boolean isSingleton() {
		return true;
	}

}
