package com.nt.sbeans;

import jakarta.inject.Named;

@Named("pEngg")
public final class PetrolEngine implements IEngine {

	@Override
	public void startEngine() {
		System.out.println("PetrolEngine.startEngine() (Engine started)");

	}

	@Override
	public void stopEngine() {
		System.out.println("PetrolEngine.startEngine() (Engine Stopped)");

	}

}
