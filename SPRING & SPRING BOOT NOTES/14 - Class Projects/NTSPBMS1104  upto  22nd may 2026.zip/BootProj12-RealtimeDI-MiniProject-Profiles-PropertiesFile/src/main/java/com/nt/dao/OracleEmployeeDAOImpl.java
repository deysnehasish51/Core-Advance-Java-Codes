//EmployeeDAOImpl.java
package com.nt.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;

import com.nt.model.Employee;

@Repository("empDAO-ora")
@Profile({"uat","prod"})
public class OracleEmployeeDAOImpl implements IEmployeeDAO {
	private  static  final String   GET_EMPS_BY_DESGS="SELECT EMPNO,ENAME,JOB,SAL FROM EMP WHERE JOB IN (?,?,?) ORDER BY JOB";
	private  static  final String   INSERT_EMP="INSERT INTO EMP(EMPNO,ENAME,JOB,SAL) VALUES(EMP_SEQ1.NEXTVAL,?,?,?)";
	
	@Autowired
	private  DataSource ds;
	
	public OracleEmployeeDAOImpl() {
		System.out.println("ORacleEmployeeDAOImpl:: 0-param constructor");
	}

	@Override
	public List<Employee> showAllEmployeesByDesgs(String desg1, String desg2, String desg3) throws Exception {
		System.out.println("OracleEmployeeDAOImpl.showAllEmployeesByDesgs()--> DataSource obj class name::"+ds.getClass());
		List<Employee> list=null;
		//get Pooled jdbc con object
		try(Connection con=ds.getConnection();
				 //create PreparedStatement object
				PreparedStatement  ps=con.prepareStatement(GET_EMPS_BY_DESGS);
				){
			   //set values to Query params
			  ps.setString(1, desg1);
			  ps.setString(2, desg2);
			  ps.setString(3,desg3);
			  //execute the Query  and  get ResultSet object
			  try(ResultSet rs=ps.executeQuery()){
				  //process the ResultSEt object records to copy to  List<Employee> class object
				  list=new ArrayList<Employee>();
				  while(rs.next()) {
					   //copy each record of RS to  Employee class  object
					  Employee  emp=new Employee();
					  emp.setEno(rs.getInt(1));
					  emp.setEname(rs.getString(2));
					  emp.setDesg(rs.getString(3));
					  emp.setSalary(rs.getFloat(4));
					  //add each Employee class object to List Collection
					  list.add(emp);
				  }//while
			  }//try2
		}//try1
		catch(SQLException se) {   // To handle known exception
			throw se;  // Exception rethrowing
		}
		catch(Exception e) { // To handle unknown Exceptions
			throw e;
		}
		return list;
	}//method

	@Override
	public int insertEmployee(Employee emp) throws Exception {
		System.out.println("OracleEmployeeDAOImpl.insertEmployee()");
		int count=0;
		try(//get  Pooled jdbc con object 
				Connection con=ds.getConnection();
				 //create the PreparedStatement object
				PreparedStatement ps=con.prepareStatement(INSERT_EMP);
				){
			  //set values to Query params
			   ps.setString(1,emp.getEname());
			   ps.setString(2,emp.getDesg());
			   ps.setFloat(3, emp.getSalary());
			    //execute  the Query
			   count=ps.executeUpdate();
		
		}
		return count;
	}

}//class

