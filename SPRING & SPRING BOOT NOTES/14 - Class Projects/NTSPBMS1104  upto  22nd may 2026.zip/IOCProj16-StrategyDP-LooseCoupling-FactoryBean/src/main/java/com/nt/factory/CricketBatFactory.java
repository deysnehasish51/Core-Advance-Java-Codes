package com.nt.factory;

import org.jspecify.annotations.Nullable;
import org.springframework.beans.factory.FactoryBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.nt.sbeans.CeatCricketBat;
import com.nt.sbeans.ICricketBat;
import com.nt.sbeans.MRFCricketBat;

@Component("batFactory")
public class CricketBatFactory implements FactoryBean<ICricketBat> {
	@Value("${bat.id}")
	private  String batId;
	@Autowired
	private  MRFCricketBat  mrfBat;
	@Autowired
	private   CeatCricketBat  ceatBat;

	@Override
	public @Nullable ICricketBat getObject() throws Exception {
		System.out.println("CricketBatFactory.getObject()");
	   switch (batId) {
	case "mrf":
		  return mrfBat;
	case "ceat":
		  return ceatBat;
	default:
		throw new IllegalArgumentException("Invalid  bat Id: " + batId);
	}

	}

	@Override
	public @Nullable Class<?> getObjectType() {
		return ICricketBat.class;
	}
	@Override
	public boolean isSingleton() {
		return true;
	}

}
