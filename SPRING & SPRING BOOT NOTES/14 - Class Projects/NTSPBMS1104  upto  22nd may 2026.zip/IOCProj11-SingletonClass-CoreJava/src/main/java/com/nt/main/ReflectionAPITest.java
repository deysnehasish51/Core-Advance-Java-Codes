package com.nt.main;

import java.lang.reflect.Constructor;

import com.nt.ston.Printer;

public class ReflectionAPITest {

	public static void main(String[] args)throws Exception {
		   //create Object of java.lang.Class  having given java class metadata
		    Class clazz=Printer.class;
		    // get all the declared constructors of the class
		    Constructor cons[]=clazz.getDeclaredConstructors();
		    //get access to  private constructor
		    cons[0].setAccessible(true);
		    //  create the object using  that accessed construtor
		    Object obj=cons[0].newInstance();
		    Object obj1=cons[0].newInstance();
		    
		    Printer p=(Printer)obj;
		    p.printData("hello");
		    

	}

}
