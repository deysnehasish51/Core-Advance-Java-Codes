package com.nt.main;

import com.nt.ston.Printer;

public class SingletonTest {

	public static void main(String[] args) {
		
		Printer prn1=Printer.getInstance();
		Printer prn2=Printer.getInstance();
		System.out.println(prn1.hashCode()+"...."+prn2.hashCode());
		System.out.println("-------------------");
		System.out.println("prn1==prn2?"+(prn1==prn2));
		System.out.println("==============");
		prn1.printData("hello");
		prn2.printData("hai");
		

	}

}
