//Cricketer.java
package com.nt.sbeans;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component("cktr")
public final class Cricketer {
	@Autowired
	//@Qualifier("${bat.id}")  --->  invalid  place holder must be placed  along with @Value annotation
	//@Qualifier(@Value("{bat.id}"))  // Invalid  becoz  @Value annotation can not be placed in @Qualifier(-) annotation
	//@Qualifer(id)  // invalid  becoz  @Qualifier(-) allows only String constants , not the String variables
	@Qualifier("cbat")
	private  ICricketBat  bat;
	
	/*@Value("${bat.id}")
	private  String id; */
	
	private Cricketer() {
		System.out.println("Cricketer:: 0-param constructor");
	}
	
	// b.method
	public  String   batting() {
		System.out.println("Cricketer.batting()");
		//use  the dependent object
		int runs=bat.scoreRuns();
		return "Cricketer has scored "+runs +" in batting";
	}

}
