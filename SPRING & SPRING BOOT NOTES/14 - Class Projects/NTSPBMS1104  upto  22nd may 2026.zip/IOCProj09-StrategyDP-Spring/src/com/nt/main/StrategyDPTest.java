//StrategyDPTest.java
package com.nt.main;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.nt.comps.Flipkart;
import com.nt.config.AppConfig;

public class StrategyDPTest {

	public static void main(String[] args) {
		System.out.println("StrategyDPTest.main()");
		try(AnnotationConfigApplicationContext ctx
			            	 =new AnnotationConfigApplicationContext(AppConfig.class) ){
			//get  Target spring bean class obj ref
			Flipkart  fpkt=ctx.getBean("fpkt",Flipkart.class);
			//invoke the b.method
			String msg=fpkt.shopping(new String[] {"shoe","trouser","shirt" }, 
					                                           new double[] {4000.0,4000.0,1000.0 });
			System.out.println(msg);
			
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		
	
	}

}
