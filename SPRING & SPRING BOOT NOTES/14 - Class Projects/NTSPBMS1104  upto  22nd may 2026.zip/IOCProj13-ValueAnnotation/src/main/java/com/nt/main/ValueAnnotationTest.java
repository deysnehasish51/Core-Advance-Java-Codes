package com.nt.main;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.core.env.Environment;

import com.nt.config.AppConfig;
import com.nt.sbeans.PersonInfo;
import com.nt.sbeans.TestInfo;

public class ValueAnnotationTest {

	public static void main(String[] args) {
		    //create  IOC container
		try(AnnotationConfigApplicationContext ctx=
				  new AnnotationConfigApplicationContext(AppConfig.class)) {
			//get spring bean class obj  ref
			PersonInfo  info=ctx.getBean("pInfo",PersonInfo.class);
			System.out.println(info);
			System.out.println("=========================");
			Environment env=ctx.getEnvironment();
			System.out.println("Env object class name:: "+env.getClass());
			System.out.println(" system property value ::"+env.getProperty("user.name"));
			System.out.println(" key value ::"+env.getProperty("per.name"));
			System.out.println("=========================");
			TestInfo  tinfo=ctx.getBean("tInfo",TestInfo.class);
			System.out.println("TestInfo obj data ::"+tinfo);
			
			
		}
		catch(Exception e) {
			e.printStackTrace();
		}


	}

}
