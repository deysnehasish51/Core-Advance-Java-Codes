//PersonalInfo.java
package com.nt.sbeans;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component("pInfo")
public class PersonInfo {
	//inject the hard coded value
	@Value("1001")
	private  Integer regNo;
	//inject the values collected from the properties file
	@Value("${per.id}")
	private  Integer id;
	@Value("${per.name}")
	private  String  name;
	@Value("${per.addrs}")
    private   String location;
	@Value("${per.age}")
    private   Integer age;
	
	// Inject the system property value
	@Value("${user.name}")
	private   String   username;
	@Value("${os.name}")
	private  String  osName;
	@Value("${os.version}")
	private  String  osVersion;
	
	// Inject  the  Env variable value
	@Value("${Path} ")
	private   String  pathData;

	//toString() (alt+shift+s,s)
	
	@Override
	public String toString() {
		return "PersonInfo [regNo=" + regNo + ", id=" + id + ", name=" + name + ", location=" + location + ", age="
				+ age + ", username=" + username + ", osName=" + osName + ", osVersion=" + osVersion + ", pathData="
				+ pathData + "]";
	}
	
	 
	
    
}
