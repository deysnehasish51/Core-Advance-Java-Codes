//TestInfo.java
package com.nt.sbeans;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

@Component("tInfo")
public class TestInfo {
	@Autowired
	private Environment env;
	
	//toString()
	public String toString() {
		return  env.getProperty("per.id")+"...."+env.getProperty("per.name")+"....."+env.getProperty("per.addrs");
	}

}
