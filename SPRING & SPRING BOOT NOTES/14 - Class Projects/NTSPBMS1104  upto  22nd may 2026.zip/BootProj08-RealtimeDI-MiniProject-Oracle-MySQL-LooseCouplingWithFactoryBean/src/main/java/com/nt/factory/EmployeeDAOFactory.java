package com.nt.factory;

import org.jspecify.annotations.Nullable;
import org.springframework.beans.factory.FactoryBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.nt.dao.IEmployeeDAO;
import com.nt.dao.MySQLEmployeeDAOImpl;
import com.nt.dao.OracleEmployeeDAOImpl;

@Component("empDAOFactory")
public class EmployeeDAOFactory implements FactoryBean<IEmployeeDAO> {
	   @Value("${choose.dao}")
       private  String  daoID;
	   
	   @Autowired
	   private  OracleEmployeeDAOImpl  oraDAO;
	   @Autowired
	   private   MySQLEmployeeDAOImpl  mysqlDAO;
	   
	@Override
	public IEmployeeDAO getObject() throws Exception {
		if(daoID.equalsIgnoreCase("empDAO-ora"))
		    return  oraDAO;
		else if(daoID.equalsIgnoreCase("empDAO-mysql"))
			return mysqlDAO;
		else
			throw  new IllegalArgumentException("Invalid  DAO Bean ID");
	}

	@Override
	public @Nullable Class<?> getObjectType() {
		return IEmployeeDAO.class;
	}
	
	@Override
	public boolean isSingleton() {
		return true;
	}

}
