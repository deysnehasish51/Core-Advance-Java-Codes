package com.nt;

import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.jdbc.autoconfigure.JdbcTemplateAutoConfiguration;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.core.env.Environment;

import com.mchange.v2.c3p0.ComboPooledDataSource;
import com.nt.controller.CollegeOperationsController;
import com.nt.factory.EmployeeDAOFactory;
import com.nt.model.Employee;

@SpringBootApplication(exclude = JdbcTemplateAutoConfiguration.class)
public class BootProj08RealtimeDiMiniProjectLayeredApplication {

    private final EmployeeDAOFactory empDAOFactory;
	@Autowired
	private Environment  env;

    BootProj08RealtimeDiMiniProjectLayeredApplication(EmployeeDAOFactory empDAOFactory) {
        this.empDAOFactory = empDAOFactory;
    }
	
	/*	@Bean(name="c3P0DS")
		public  DataSource  createDS()throws Exception {
			 ComboPooledDataSource  ds=new ComboPooledDataSource();
			 ds.setDriverClass(env.getProperty("spring.datasource.driver-class-name"));
			 ds.setJdbcUrl(env.getProperty("spring.datasource.url"));
			 ds.setUser(env.getProperty("spring.datasource.username"));
			 ds.setPassword(env.getProperty("spring.datasource.password"));
			 return  ds;
		}
	*/
	public static void main(String[] args) {
		  //create IOC container
		try(ConfigurableApplicationContext ctx=
				  SpringApplication.run(BootProj08RealtimeDiMiniProjectLayeredApplication.class, args);
				// create  Scannersy
				Scanner sc=new Scanner(System.in);
				){
			   System.out.println("Spring beans count ::"+ctx.getBeanDefinitionCount());
						//get Access to  Controller object  ref
						CollegeOperationsController  controller=ctx.getBean("collegeController",CollegeOperationsController.class);
			            //use  scanner  for insert employee inputs reading
						System.out.println("Enter  employee name::");
						String name=sc.next();
						System.out.println("Enter employee desg::");
						String desg=sc.next();
						System.out.println("Enter  employee  salary::");
						float salary=sc.nextFloat();
						//create Employee class object
						Employee emp=new Employee();
						emp.setEname(name);emp.setDesg(desg);emp.setSalary(salary);
						
						//invoke the method
						String  resultMsg=controller.addEmployeeDetails(emp);
						System.out.println(resultMsg);
						
						System.out.println("=========================================");
						
						//use scanner 
						System.out.println("Enter  desg1::");
						String desg1=sc.next();
						System.out.println("Enter  desg2::");
						String desg2=sc.next();
						System.out.println("Enter  desg3::");
						String desg3=sc.next();
						
						//invoke b.method
						List<Employee>  list=controller.processEmployeesByDesgs(desg1, desg2, desg3);
						//process the list
						list.forEach(emp1->{
							System.out.println(emp1);
						});
						System.out.println("=====================================");
						System.out.println("Spring Bean ids ::"+Arrays.toString(ctx.getBeanDefinitionNames()));
		}//try
		catch(Exception e) {
			e.printStackTrace();
			System.out.println("problem :::"+e.getMessage());
		}
	}//main

}//class

