package com.nt.main;

import java.util.Arrays;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class DefaultBeanIdsTest {

	public static void main(String[] args) {
		
		try(ClassPathXmlApplicationContext  ctx=
				      new ClassPathXmlApplicationContext("com/nt/cfgs/applicationContext.xml")){
			String ids[]=ctx.getBeanDefinitionNames();
			System.out.println("Bean ids  ::"+Arrays.toString(ids));
		}
		catch(Exception e) {
			e.printStackTrace();
		}

	}

}
