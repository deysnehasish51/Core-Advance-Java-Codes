//DependencyManagementTest.java (main class/Client app)
package com.nt.main;

import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.context.support.FileSystemXmlApplicationContext;

import com.nt.sbeans.WishMessageGenerator;

public class DependencyMgmtTest {

	public static void main(String[] args) {
		// create  IOC container
		try(ClassPathXmlApplicationContext  ctx=
				      new ClassPathXmlApplicationContext("com/nt/cfgs/applicationContext.xml")){
			//get spring bean class obj refs
			WishMessageGenerator  generator1=ctx.getBean("wmg",WishMessageGenerator.class);
			WishMessageGenerator  generator2=ctx.getBean("wmg",WishMessageGenerator.class);
			System.out.println(generator1.hashCode()+"..."+generator2.hashCode());
			System.out.println("-----------------------------------");
			WishMessageGenerator  generator11=ctx.getBean("wmg1",WishMessageGenerator.class);
			WishMessageGenerator  generator22=ctx.getBean("wmg1",WishMessageGenerator.class);
			System.out.println(generator11.hashCode()+"..."+generator22.hashCode());
	
			
		}//try
		catch(Exception e) {
			e.printStackTrace();
		}
		
		 
	
	}

}
