package com.nt.main;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.nt.ston.Printer;

public class SpringBeanScopesTest {

	public static void main(String[] args) {
		try(ClassPathXmlApplicationContext ctx=
				   new  ClassPathXmlApplicationContext("com/nt/cfgs/applicationContext.xml") ){
			   //get Spring Bean class obj ref
			Printer p11=ctx.getBean("p1",Printer.class);
			Printer p12=ctx.getBean("p2",Printer.class);
			System.out.println(p11.hashCode()+"...."+p12.hashCode());
			
			
		}
		catch(Exception e) {
			e.printStackTrace();
		}

	}

}
