//Vehicle.java
package com.nt.sbeans;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

@Component("vehicle")
public final class Vehicle {
	@Autowired
	@Qualifier("pEngg")
	private IEngine engg;
	
	public   void  Jounery (String startPlace ,String endPlace) {
		System.out.println("jounery started at ::"+startPlace);
		engg.startEngine();
		System.out.println("Journery is going  on .....from "+startPlace+"...."+endPlace);
		engg.stopEngine();
		System.out.println("Jounery  stopped at ::"+endPlace);
	}

}
