package com.nt.sbeans;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import lombok.Data;

@Component("catalog")
@Data
public class CourseCatalog {
	@Value("${course.corejava.price}")
	private    Float  cjPrice;
	@Value("${course.advjava.price}")
	private    Float   ajPrice;
	@Value("${course.spbms.price}")
	private   Float   spbmsPrice;
	@Value("${course.aws.price}")
	private   Float   awsPrice;
	@Value("${course.devops.price}")
	private    Float  devOpsPrice;
	@Value("${course.testing.price}")
		private  Float   testingPrice;
	@Value("${course.ui.price}")
	private  Float  uiPrice;
	@Value("${course.oracle.price}")
	private   Float  oraclePrice;

}
