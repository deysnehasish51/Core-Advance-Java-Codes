package com.nt;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.core.env.Environment;

import com.nt.sbeans.TrainingInistitute;

@SpringBootApplication
public class BootProj09ValueAnnotationSpelApplication {

	public static void main(String[] args) {
		   //create  IOC container
		try(ConfigurableApplicationContext ctx=
				  SpringApplication.run(BootProj09ValueAnnotationSpelApplication.class, args)){
			 //get Spring Bean class obj ref
			TrainingInistitute  inistitute=ctx.getBean("inistitute",TrainingInistitute.class);
			 inistitute.calculateDiscountFee(20.0f);
			System.out.println("data is ::"+inistitute);
			System.out.println("========================");
			 Environment  env=ctx.getEnvironment();
			System.out.println("aj price "+env.getProperty("course.advjava.price"));
			System.out.println("env obj class name ::"+env.getClass());
		}//try
		catch(Exception e) {
			e.printStackTrace();
		}
		
	}

}
