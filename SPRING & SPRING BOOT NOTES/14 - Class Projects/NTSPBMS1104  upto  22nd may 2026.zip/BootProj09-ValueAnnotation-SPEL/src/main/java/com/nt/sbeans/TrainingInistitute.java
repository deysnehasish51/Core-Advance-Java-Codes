package com.nt.sbeans;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import lombok.Data;

@Component("inistitute")
@Data
public class TrainingInistitute {
	  // inject the hard coded value
	@Value("10001")
	private   Integer tid;
	// inject  the values collected from the properties file
	@Value("${ti.name}")
	private   String  name;
	@Value("${ti.addrs}")
	private  String   addrs;
	@Value("${ti.size}")
	private    Float  size;
	// Inject the System property values
	@Value("${user.name}")
	private  String username;
	@Value("${os.version}")
	private   String  osVersion;
	//Inject  enviroment variable values
	@Value("${Path}")
	private  String pathData;
	
	@Value("#{catalog.cjPrice+ catalog.ajPrice+ catalog.spbmsPrice + catalog.oraclePrice+ catalog.uiPrice+ catalog.awsPrice+catalog.devOpsPrice+catalog.testingPrice}")
	private   Float   fullStackJavaPrice;
	@Value("#{catalog.ajPrice>5000}")
	private    Boolean isAjPriceHigh;
	
	  //@Value("#{inistitute.fullStackJavaPrice -  (inistitute.fullStackJavaPrice *0.3f) } ")
      private   Float finalPrice;
	  
	  public   Float    calculateDiscountFee(float discountPercent) {
		  finalPrice=fullStackJavaPrice-fullStackJavaPrice*discountPercent/100.0f;
		  return finalPrice;
	  }
}
