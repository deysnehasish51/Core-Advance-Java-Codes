package com.nt.runners;

import java.util.Set;

import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

@Component
@Order(-21)
public class MyTestRunnerr2 implements ApplicationRunner, Ordered {

	@Override
	public void run(ApplicationArguments args) throws Exception {
		System.out.println("MyTestRunnerr2.run() (Application Runner)");
		 
		  System.out.println(" Non-optional args are ::"+args.getNonOptionArgs());
		  System.out.println("Option args names ---- values ::");
		  Set<String>  optNames=args.getOptionNames();
		  optNames.forEach(name->{
			  System.out.println(name+"...."+args.getOptionValues(name));
		  });
	 System.out.println("---------------------------------------------------------");
		
	}

	@Override
	public int getOrder() {
		return 10;
	}

}
