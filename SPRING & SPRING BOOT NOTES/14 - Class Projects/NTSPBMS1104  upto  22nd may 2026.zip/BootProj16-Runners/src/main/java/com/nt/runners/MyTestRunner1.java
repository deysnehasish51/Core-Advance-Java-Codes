package com.nt.runners;

import java.util.Arrays;

import org.springframework.boot.CommandLineRunner;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

@Component
//@Order(-5)
public class MyTestRunner1 implements CommandLineRunner{ //,Ordered {

	@Override
	public void run(String... args) throws Exception {
		System.out.println("MyTestRunner1.run()  (CommandLine Runner)");
		System.out.println("Command Line Args ::"+Arrays.toString(args));
		System.out.println("------------------------------------------------");

	}

	/*@Override
	public int getOrder() {
		// TODO Auto-generated method stub
		return 5;
	}*/

}
