package com.nt.main;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.nt.config.AppConfig;
import com.nt.sbeans.VoterOperations;

public class SpringBeanLifeCycleTest {

	public static void main(String[] args) {
		//create the IOC container
		try(AnnotationConfigApplicationContext ctx= new
				 AnnotationConfigApplicationContext(AppConfig.class)){
			 //get Spring Bean class obj ref
			VoterOperations operations=ctx.getBean("voter",VoterOperations.class);
			//invoke the b.method
			String msg=operations.checkVotingElgibility();
			System.out.println(msg);
		}
		catch(Exception e) {
			e.printStackTrace();
		}

	}

}
