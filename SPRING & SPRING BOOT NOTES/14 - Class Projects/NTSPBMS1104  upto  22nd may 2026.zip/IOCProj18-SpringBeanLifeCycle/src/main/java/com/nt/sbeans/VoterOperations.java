//VoterOperations.java
package com.nt.sbeans;

import java.time.LocalDate;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import jakarta.annotation.PostConstruct;
import jakarta.annotation.PreDestroy;

@Component("voter")
public class VoterOperations {
	@Value("${voter.id}")
	private  Integer  id;
	@Value("${voter.name}")
	private  String name;
	//@Value("${voter.age}")
	private   Integer age;
	private   LocalDate  dov;
	
	static {
		System.out.println("VoterOperations:: static block");
	}
	
	public VoterOperations() {
		System.out.println("VoterOperations:: 0-param constructor");
	}
	
	@Value("${voter.age}")
	public void setAge(Integer  age) {
		System.out.println("VoterOperations.setAge()");
		this.age=age;
	}
	
	@PostConstruct
	public  void  myInit() {
		System.out.println("VoterOperations.myInit()");
		//initialize  the left over properties
		dov=LocalDate.now();
		//check  wheather imp properties are injected with  correct values or not
		if(age<=0  || age>120)
			throw new IllegalArgumentException("Invalid age value");
		
	}
	
	@PreDestroy
	public  void  myDestroy() {
		System.out.println("VoterOperations.myDestroy()");
		//nullify the bean properties
		name=null;
		id=null;
		dov=null;
		age=null;
	}
	
	//b.method
	public   String checkVotingElgibility() {
		myDestroy();
		System.out.println("VoterOperations.checkVotingElgibility() (business method)");
		if(age>=18)
			return  "Mr/Miss/Mrs."+name+"  u r  eligible for voting . verified on ::"+dov;
		else
			return  "Mr/Miss/Mrs."+name+"  u r not  eligible for voting . verified on ::"+dov;
	}
	
	
	

}
