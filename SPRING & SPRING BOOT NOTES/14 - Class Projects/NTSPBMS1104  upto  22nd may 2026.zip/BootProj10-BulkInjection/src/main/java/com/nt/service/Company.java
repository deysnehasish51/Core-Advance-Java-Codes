package com.nt.service;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import lombok.Data;
import lombok.ToString;

@Component("comp")
@ConfigurationProperties(prefix = "org.nit")
@Data
@ToString
public class Company {
	private  Integer cno;
	private  String  cname;
	//@Value("${my.addrs}")
	private String caddrs;
	private  Integer size;

}
