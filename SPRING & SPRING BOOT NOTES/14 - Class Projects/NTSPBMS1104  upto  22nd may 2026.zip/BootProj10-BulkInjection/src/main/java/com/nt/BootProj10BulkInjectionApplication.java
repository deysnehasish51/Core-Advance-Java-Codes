package com.nt;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.PropertySource;

import com.nt.service.Company;
import com.nt.service.Employee;

@SpringBootApplication
//@PropertySource("myfile.properties")
public class BootProj10BulkInjectionApplication {

	public static void main(String[] args) {
		   //create  IOC container
		try(ConfigurableApplicationContext ctx=
				 SpringApplication.run(BootProj10BulkInjectionApplication.class, args)){
			/*Company comp=ctx.getBean("comp",Company.class);
			System.out.println(comp);*/
			//get   access to spring bean class obj ref
			Employee  emp=ctx.getBean("emp",Employee.class);
			System.out.println(emp);
			
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}

}
