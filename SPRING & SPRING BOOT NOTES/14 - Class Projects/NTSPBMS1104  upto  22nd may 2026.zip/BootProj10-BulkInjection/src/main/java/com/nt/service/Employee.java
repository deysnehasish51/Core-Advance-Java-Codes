package com.nt.service;

import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import lombok.Data;

@Component("emp")
@ConfigurationProperties(prefix = "com.nt")
@Data
public class Employee {
	private  Integer  eno;
	private  String ename;
	private  String  eaddrs;
	private   String[] favColors;
	private   List<String>  friends;
	private   Set<Long>  phones;
	private  Map<String,Object>  idDetails;
	//@Autowired
	private   Company company;
	
	@Autowired
	public void  setOrg(Company  company) {
		System.out.println("Employee.setOrg()");
		this.company=company;
	}

}
