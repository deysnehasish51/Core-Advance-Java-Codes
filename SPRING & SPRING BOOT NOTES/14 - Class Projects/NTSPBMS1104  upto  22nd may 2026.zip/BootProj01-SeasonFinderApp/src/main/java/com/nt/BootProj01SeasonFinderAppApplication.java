package com.nt;

import java.time.LocalDate;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.Bean;

import com.nt.sbeans.SeasonFinder;

@SpringBootApplication
public class BootProj01SeasonFinderAppApplication {
	
	@Bean(name="ldt")
	public   LocalDate  createDate() {
		  return  LocalDate.now();
	}

	public static void main(String[] args) {
		 // get Access to IOC container
		try(ConfigurableApplicationContext ctx=SpringApplication.run(BootProj01SeasonFinderAppApplication.class, args)){
		  //get Spring Bean class obj  ref
		SeasonFinder  finder=ctx.getBean("sf",SeasonFinder.class);
		//invoke the b.method
		String msg=finder.findSeason();
		System.out.println(msg);
		System.out.println("==================");
		System.out.println("Spring Beans count :::"+ctx.getBeanDefinitionCount());
		}//try
		catch(Exception e) {
			e.printStackTrace();
		}
		
		
	}

}
