package com.nt;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.ImportResource;

import com.nt.sbeans.Vehicle;

@SpringBootApplication
@ImportResource("com/nt/cfgs/applicationContext.xml")
public class BootProj02StrategyDpApplication {

	public static void main(String[] args) {
		 //create  IOC container
		try(ConfigurableApplicationContext ctx=SpringApplication.run(BootProj02StrategyDpApplication.class, args)){
			  //get Spring Bean class obj ref
			 Vehicle vehicle=ctx.getBean("vehicle",Vehicle.class);
			 //invoke the method
			 vehicle.Jounery("hyd", "pune");
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}

}
