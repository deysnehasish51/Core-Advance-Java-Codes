//LuxoryCar.java
package com.nt.comps;

public class LuxoryCar implements ICar {
	
	public LuxoryCar() {
		System.out.println("LuxoryCar:: 0-param constructor");
	}

	@Override
	public void drive() {
		System.out.println("LuxoryCar::drive()-Driving Rolls Royace car ");

	}

}
