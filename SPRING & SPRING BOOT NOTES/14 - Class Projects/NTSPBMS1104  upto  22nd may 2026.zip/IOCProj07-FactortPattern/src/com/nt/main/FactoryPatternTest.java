package com.nt.main;

import com.nt.comps.ICar;
import com.nt.factory.CarFactory;

public class FactoryPatternTest {

	public static void main(String[] args) {
	   ICar  car1=CarFactory.getInstance("standard");
	   car1.drive();
	   System.out.println("-----------------------------------");
	   ICar  car2=CarFactory.getInstance("luxory");
	   car2.drive();
	   System.out.println("-----------------------------------");
	   
	   ICar  car3=CarFactory.getInstance("sports");
	   car3.drive();
	   
	}

}
