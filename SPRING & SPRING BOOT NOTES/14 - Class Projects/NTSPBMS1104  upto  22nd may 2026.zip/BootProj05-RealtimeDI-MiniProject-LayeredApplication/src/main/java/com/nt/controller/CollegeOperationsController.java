package com.nt.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import com.nt.model.Employee;
import com.nt.service.IEmployeeMgmtService;

@Controller("collegeController")
public class CollegeOperationsController {
	@Autowired
	private  IEmployeeMgmtService empService;
	
	public CollegeOperationsController() {
		System.out.println("CollegeOperationsController:: 0-param constructor");
	}
	
	public List<Employee>   processEmployeesByDesgs(String desg1,String desg2,String desg3)throws Exception{
		System.out.println("CollegeOperationsController.processEmployeesByDesgs()");
		//use    service
		List<Employee>  list=empService.showEmployeesByDesgs(desg1, desg2, desg3);
		return list;
	}
	 
	public  String    addEmployeeDetails(Employee emp)throws Exception {
		System.out.println("CollegeOperationsController.addEmployeeDetails()");
		//use  service
		String  resultMsg=empService.registerEmployee(emp);
		return  resultMsg;
	}
	
	
	

}
