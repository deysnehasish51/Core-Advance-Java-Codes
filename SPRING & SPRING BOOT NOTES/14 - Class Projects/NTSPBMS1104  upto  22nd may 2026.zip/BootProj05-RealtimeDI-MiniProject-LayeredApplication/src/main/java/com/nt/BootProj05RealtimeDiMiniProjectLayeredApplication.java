package com.nt;

import java.util.List;
import java.util.Scanner;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;

import com.nt.controller.CollegeOperationsController;
import com.nt.model.Employee;

@SpringBootApplication
public class BootProj05RealtimeDiMiniProjectLayeredApplication {

	public static void main(String[] args) {
		  //create IOC container
		try(ConfigurableApplicationContext ctx=
				  SpringApplication.run(BootProj05RealtimeDiMiniProjectLayeredApplication.class, args);
				// create  Scannersy
				Scanner sc=new Scanner(System.in);
				){
			      System.out.println("Start of main(-) method");
						//get Access to  Controller object  ref
						CollegeOperationsController  controller=ctx.getBean("collegeController",CollegeOperationsController.class);
			            //use  scanner  for insert employee inputs reading
						System.out.println("Enter  employee name::");
						String name=sc.next();
						System.out.println("Enter employee desg::");
						String desg=sc.next();
						System.out.println("Enter  employee  salary::");
						float salary=sc.nextFloat();
						//create Employee class object
						Employee emp=new Employee();
						emp.setEname(name);emp.setDesg(desg);emp.setSalary(salary);
						
						//invoke the method
						String  resultMsg=controller.addEmployeeDetails(emp);
						System.out.println(resultMsg);
						
						System.out.println("=========================================");
						
						//use scanner 
						System.out.println("Enter  desg1::");
						String desg1=sc.next();
						System.out.println("Enter  desg2::");
						String desg2=sc.next();
						System.out.println("Enter  desg3::");
						String desg3=sc.next();
						
						//invoke b.method
						List<Employee>  list=controller.processEmployeesByDesgs(desg1, desg2, desg3);
						//process the list
						list.forEach(emp1->{
							System.out.println(emp1);
						});
		}//try
		catch(Exception e) {
			e.printStackTrace();
			System.out.println("problem :::"+e.getMessage());
		}
	}//main

}//class

