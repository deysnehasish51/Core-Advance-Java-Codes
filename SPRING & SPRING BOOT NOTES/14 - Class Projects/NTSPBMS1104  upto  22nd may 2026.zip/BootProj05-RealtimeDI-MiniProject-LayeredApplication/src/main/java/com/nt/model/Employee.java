package com.nt.model;

import lombok.Data;

@Data
/*@Setter
@Getter
@ToString
@EqualsAndHashCode
@NoArgsConstructor
@AllArgsConstructor
*/
public class Employee {
	private Integer eno;
	private  String  ename;
	private  String  desg;
	private   Float salary;
	private  Float grossSalary;
	private  Float netSalary;
	

}
