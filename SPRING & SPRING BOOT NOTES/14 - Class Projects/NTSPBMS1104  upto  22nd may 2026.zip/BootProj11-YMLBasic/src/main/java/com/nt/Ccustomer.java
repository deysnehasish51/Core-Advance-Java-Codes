//Customer.java
package com.nt;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import lombok.Data;

@Component("cust")
@ConfigurationProperties(prefix = "cust.info")
@Data
public class Ccustomer {
	private  String name;
	private  String  addrs;
	private  Integer age;
	private  String company;
	

}
