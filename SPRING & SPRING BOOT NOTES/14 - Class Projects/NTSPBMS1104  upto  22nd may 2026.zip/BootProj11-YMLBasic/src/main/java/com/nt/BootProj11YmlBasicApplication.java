package com.nt;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.PropertySource;

import com.nt.service.Employee;

@SpringBootApplication
@PropertySource("myfile.yml")
public class BootProj11YmlBasicApplication {

	public static void main(String[] args) {
		  //get  IOC container
		try(ConfigurableApplicationContext ctx=
				SpringApplication.run(BootProj11YmlBasicApplication.class, args)){
			 //get  Spring bean class obj ref
			Ccustomer cust=ctx.getBean("cust",Ccustomer.class);
			System.out.println(cust);
			System.out.println("===================");
			Employee  emp=ctx.getBean("emp",Employee.class);
			System.out.println(emp);
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}//main
}//class
