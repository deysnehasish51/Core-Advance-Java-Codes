//StrategyDPTest.java
package com.nt.main;

import com.nt.comps.Flipkart;
import com.nt.factory.FlipkartFactory;

public class StrategyDPTest {

	public static void main(String[] args) {
		System.out.println("StrategyDPTest.main()");
		//get  Flipkart object  from factory
		Flipkart fpkt=FlipkartFactory.getInstance("dtdc");
		// invoke the b.mnethod
		String  msg=fpkt.shopping(new String[] {"trouser","shirt","shoe"},
				                                           new double[] {4000.0, 3000.0, 5000.0});
		System.out.println(msg);
		System.out.println("---------------------------");
		Flipkart fpkt1=FlipkartFactory.getInstance("dtdc");
		
		
	
	}

}
