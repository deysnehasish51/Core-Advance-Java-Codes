//FlipkartFactory.java (Factory Pattern class)
package com.nt.factory;

import com.nt.comps.BlueDart;
import com.nt.comps.DTDC;
import com.nt.comps.Flipkart;
import com.nt.comps.ICourier;

public class FlipkartFactory {
	
	//public static factory method  having factory pattern logic
	public  static   Flipkart  getInstance(String courierType) {
		System.out.println("FlipkartFactory.getInstance()");
		 //create  one of the Dependent class object based on corurier name that is recived
		 ICourier courier=null;
		 if(courierType.equalsIgnoreCase("bdart"))
			 courier=new BlueDart();
		 else if(courierType.equalsIgnoreCase("dtdc"))
			 courier=new DTDC();
		 else
			 throw new IllegalArgumentException("Invalid  Courier type");
		 //create target class object
		  Flipkart  fpkt=new Flipkart();
		  //assign dependent class object to target class object
		  fpkt.setCourier(courier);
		  //return target object inejected with dependent object
		  return fpkt;
	}

}
