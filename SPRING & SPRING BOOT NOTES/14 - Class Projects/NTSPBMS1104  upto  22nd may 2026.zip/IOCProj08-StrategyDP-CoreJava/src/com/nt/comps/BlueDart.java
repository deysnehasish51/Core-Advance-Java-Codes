//BlueDart.java (Dependent class)
package com.nt.comps;


public  final class BlueDart implements ICourier {
	
	public BlueDart() {
		System.out.println("BlueDart:: 0-param constructor");
	}

	@Override
	public String deliver(int oid) {
		
		return oid+" order   items are ready for delivery using  BlueDart Courier Service";
	}

}
