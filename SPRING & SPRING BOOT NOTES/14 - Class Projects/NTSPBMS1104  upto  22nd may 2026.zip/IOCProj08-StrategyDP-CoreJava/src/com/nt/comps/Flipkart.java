//Flipkart.java (target class)
package com.nt.comps;

import java.util.Arrays;
import java.util.Random;

public final class Flipkart {
	//HAS-A property
	private  ICourier  courier;
	
	
	public Flipkart() {
		System.out.println("Flipkart:: 0-param constructor");
	}
	
	//  setter method for injection
	public void  setCourier(ICourier courier) {
		System.out.println("Flipkart.setCourier()");
		this.courier=courier;
	}
	
	//b.method
	public  String shopping(String[] items , double [] prices) {
	     System.out.println("Flipkart.shopping()");
	      //calculate bill amount
	     double bamt=0.0;
	     for(double p: prices) {
	    	 bamt=bamt+p;
	     }
	     //generate random number  as the order id
	      int oid=new Random().nextInt(10000);
	      //invoke deliver(-) of courier 
	      String msg=courier.deliver(oid);
		//prepare final  message
	       String finalMsg=Arrays.toString(items)+"  are purchased having prices::"+Arrays.toString(prices)+" with bill amount:"+bamt+"..."+msg;
	    return finalMsg;
	}
	
	
	

}
