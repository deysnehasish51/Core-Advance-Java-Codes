//ICourier.java  (Common Interface)
package com.nt.comps;

public interface ICourier {
    public  String deliver(int oid);
}
