package com.nt.runners;

import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

import com.nt.controller.CollegeOperationsController;
import com.nt.model.Employee;

@Component
public class MiniProjectTestRunner implements CommandLineRunner {
	@Autowired
	private CollegeOperationsController  controller;

	@Override
	public void run(String... args) throws Exception {
         System.out.println("MiniProjectTestRunner.run()");
	try(Scanner sc=new Scanner(System.in);){
		
            //use  scanner  for insert employee inputs reading
			System.out.println("Enter  employee name::");
			String name=sc.next();
			System.out.println("Enter employee desg::");
			String desg=sc.next();
			System.out.println("Enter  employee  salary::");
			float salary=sc.nextFloat();
			//create Employee class object
			Employee emp=new Employee();
			emp.setEname(name);emp.setDesg(desg);emp.setSalary(salary);
			
			//invoke the method
			String  resultMsg=controller.addEmployeeDetails(emp);
			System.out.println(resultMsg);
			
			System.out.println("=========================================");
			
			//use scanner 
			System.out.println("Enter  desg1::");
			String desg1=sc.next();
			System.out.println("Enter  desg2::");
			String desg2=sc.next();
			System.out.println("Enter  desg3::");
			String desg3=sc.next();
			
			//invoke b.method
			List<Employee>  list=controller.processEmployeesByDesgs(desg1, desg2, desg3);
			//process the list
			list.forEach(emp1->{
				System.out.println(emp1);
			});
      }//try
    catch(Exception e) {
             e.printStackTrace();
             System.out.println("problem :::"+e.getMessage());
     }
  }

}
