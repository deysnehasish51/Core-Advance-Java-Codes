package com.nt;

import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.core.env.Environment;

import com.nt.controller.CollegeOperationsController;
import com.nt.model.Employee;

@SpringBootApplication
public class BootProj15RealtimeDiMiniProjectLayeredApplication {

	public static void main(String[] args) {
		  //create IOC container
				  SpringApplication.run(BootProj15RealtimeDiMiniProjectLayeredApplication.class, args);
	}//main

}//class

