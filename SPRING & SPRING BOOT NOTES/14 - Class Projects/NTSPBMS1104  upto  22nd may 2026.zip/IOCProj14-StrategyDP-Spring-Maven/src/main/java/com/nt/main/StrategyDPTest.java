//StrategyDPTest.java
package com.nt.main;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.nt.config.AppConfig;
import com.nt.sbeans.Cricketer;

public class StrategyDPTest {

	public static void main(String[] args) {
		//create  IOC container
		 try(AnnotationConfigApplicationContext  ctx=
				  new AnnotationConfigApplicationContext(AppConfig.class)){
			 //get target spring bean class obj ref
			 Cricketer  cricketer=ctx.getBean("cktr",Cricketer.class);
			 String msg=cricketer.batting();
			 System.out.println(msg);
		 }
		 catch(Exception e) {
			 e.printStackTrace();
		 }

	}//main

}//class

