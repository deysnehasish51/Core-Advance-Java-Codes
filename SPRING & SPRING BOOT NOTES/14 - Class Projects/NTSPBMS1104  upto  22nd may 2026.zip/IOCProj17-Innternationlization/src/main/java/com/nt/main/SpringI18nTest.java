package com.nt.main;

import java.util.Locale;
import java.util.Scanner;

import org.springframework.cglib.core.Local;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.nt.config.AppConfig;

public class SpringI18nTest {

	public static void main(String[] args) {
		//create  IOC container
		try(AnnotationConfigApplicationContext  ctx=
				 new  AnnotationConfigApplicationContext(AppConfig.class);
				Scanner sc=new Scanner(System.in);
				){
			//read language and country code
			System.out.println("Enter  Language Code::");
			String lang=sc.next();
			System.out.println("Enter Country code::");
			String country=sc.next();
			//create Locale object
			Locale locale=Locale.of(lang, country);
			//read the messages by using ctx.getMessage(-) method
			String msg1=ctx.getMessage("wish.message", new Object[] {"raja" }, "msg1", locale);
			String msg2=ctx.getMessage("sad.message", new Object[] { }, "msg2", locale);
			String msg3=ctx.getMessage("angry.message", new Object[] { }, "msg3", locale);
			String msg4=ctx.getMessage("goodbye.message", new Object[] { }, "msg4", locale);
			System.out.println(msg1+"...."+msg2+"...."+msg3+"...."+msg4);
		}
		catch(Exception e) {
			e.printStackTrace();
		}

	}

}
