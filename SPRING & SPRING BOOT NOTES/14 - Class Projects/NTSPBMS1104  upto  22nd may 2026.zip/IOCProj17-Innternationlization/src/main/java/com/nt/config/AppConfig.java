//AppConfig.java
package com.nt.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.support.ResourceBundleMessageSource;

@Configuration
public class AppConfig {
	
	
	@Bean(name="messageSource11")   //fixed bean id
	public    ResourceBundleMessageSource  createRDBMS() {
		ResourceBundleMessageSource  source=new ResourceBundleMessageSource();
		source.setBasename("com/nt/commons/App");
		return source;
	}

}
